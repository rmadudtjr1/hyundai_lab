"""ADK 에이전트가 Cloud Run MCP 서버의 도구를 쓰도록 연결 (서비스 계정 ID 토큰 인증).

MCP_URL=https://he-mcp-xxxx.a.run.app/mcp adk web .   (이 파일이 있는 폴더의 상위에서)
"""
import os
from google.adk.agents import LlmAgent
from google.adk.tools.mcp_tool import McpToolset, StreamableHTTPConnectionParams

MCP_URL = os.environ.get("MCP_URL", "http://localhost:8080/mcp")


def id_token_headers(_ctx=None) -> dict:
    """Cloud Run IAM 인증용 ID 토큰. 로컬 주소면 헤더 없음. 토큰은 호출마다 새로 받아 만료 문제를 피합니다."""
    if MCP_URL.startswith("http://localhost"):
        return {}
    import google.auth.transport.requests
    from google.oauth2 import id_token
    audience = MCP_URL.rsplit("/mcp", 1)[0]
    return {"Authorization": f"Bearer {id_token.fetch_id_token(google.auth.transport.requests.Request(), audience)}"}


root_agent = LlmAgent(
    name="service_data_agent",
    model=os.environ.get("MODEL_FAST", "gemini-3.8-flash"),
    instruction=("AS·현장 데이터는 MCP 도구로만 조회합니다. 현장 전체 이력처럼 오래 걸리는 추출은 "
                 "start_ticket_export 후 get_export_result를 state가 DONE이 될 때까지 확인합니다."),
    tools=[McpToolset(connection_params=StreamableHTTPConnectionParams(url=MCP_URL, timeout=30),
                      header_provider=id_token_headers)],
)
