"""(과제 참고) Cloud SQL PostgreSQL을 비동기 커넥터 + 커넥션 풀로 조회하는 MCP 도구.
pip install "cloud-sql-python-connector[asyncpg]" sqlalchemy[asyncio]
server.py에 붙여 넣고 @mcp.tool 로 등록하세요. 커넥션 풀은 프로세스당 1개만 만들어 재사용합니다.
"""
import os
from google.cloud.sql.connector import create_async_connector
from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine
from sqlalchemy import text

_engine: AsyncEngine | None = None


async def engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        connector = await create_async_connector()
        _engine = create_async_engine(
            "postgresql+asyncpg://",
            async_creator=lambda: connector.connect_async(os.environ["INSTANCE"], "asyncpg",
                                                          user=os.environ["DB_USER"], password=os.environ["DB_PASS"], db="he"),
            pool_size=5, max_overflow=5, pool_timeout=10, pool_recycle=1800)
    return _engine


async def site_info(site_id: str) -> dict:
    """현장 마스터 조회 (Cloud SQL)."""
    async with (await engine()).connect() as conn:
        row = (await conn.execute(text("SELECT * FROM sites WHERE site_id = :s"), {"s": site_id})).mappings().first()
    return dict(row) if row else {"status": "not_found"}
