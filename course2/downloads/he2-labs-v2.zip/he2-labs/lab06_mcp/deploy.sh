#!/usr/bin/env bash
# Cloud Run 배포: 인증 필수, 최소 인스턴스 1(콜드 스타트 방지), 요청 타임아웃 15분 (최대 60분)
# 사용: PROJECT_ID=he-ax-lab-team1 bash deploy.sh
set -euo pipefail
: "${PROJECT_ID:?}"; REGION="${REGION:-asia-northeast3}"
rm -rf common && cp -r ../common common
gcloud run deploy he-mcp --source . --project "$PROJECT_ID" --region "$REGION" \
  --no-allow-unauthenticated \
  --service-account "he-lab-runner@${PROJECT_ID}.iam.gserviceaccount.com" \
  --min-instances 1 --max-instances 5 --concurrency 40 --timeout 900 \
  --set-env-vars "GOOGLE_CLOUD_PROJECT=${PROJECT_ID},REGION=${REGION},BQ_DATASET=${BQ_DATASET:-he_ax}"
# 사내망 DB·API가 필요하면 Direct VPC egress 추가:
#   --network=NETWORK --subnet=SUBNET --vpc-egress=private-ranges-only
# 비밀번호·API 키는 Secret Manager: --set-secrets "DB_PASS=he-db-pass:latest"
echo "로컬 확인: gcloud run services proxy he-mcp --region=$REGION --port=8080 → python client_test.py"
