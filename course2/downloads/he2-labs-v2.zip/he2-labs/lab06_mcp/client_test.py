"""MCP 서버 연결 시험: 도구 목록 → 세 도구 호출.  python client_test.py [http://localhost:8080/mcp]"""
import asyncio, json, sys
from mcp.client.client import Client

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080/mcp"


def payload(res):
    if getattr(res, "structured_content", None):
        return res.structured_content
    return json.loads(res.content[0].text)


async def main():
    async with Client(URL) as c:
        tools = await c.list_tools()
        print("도구:", [t.name for t in tools.tools])
        r = payload(await c.call_tool("query_recurrence", {"min_recur": 10}))
        print("재발 10건 이상:", [(x["site_name"], x["recur"]) for x in r["rows"]])
        job = payload(await c.call_tool("start_ticket_export", {"site_id": "S901"}))
        print("추출 시작:", job)
        for _ in range(30):
            res = payload(await c.call_tool("get_export_result", {"job_id": job["job_id"], "location": job.get("location", "")}))
            if res["state"] == "DONE":
                print(f"추출 완료: {res['total']}건, 첫 행 {res['rows'][0]['received_at']}"); break
            await asyncio.sleep(2)

asyncio.run(main())
