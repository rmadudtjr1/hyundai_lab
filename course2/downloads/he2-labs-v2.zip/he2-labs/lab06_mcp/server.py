"""lab06 · 사내 AS 데이터 MCP 서버 (MCP Python SDK 2.x, streamable HTTP, Cloud Run 배포용).

로컬:  LAB_MODE=local python server.py        → http://localhost:8080/mcp
타임아웃 없이 만드는 원칙
 1) 오래 걸리는 조회는 start → get_result 두 도구로 나눔 (BigQuery 작업 ID, 서버 메모리에 상태 없음)
 2) 블로킹 클라이언트 호출은 asyncio.to_thread 로 이벤트 루프 밖에서
 3) stateless_http=True: 어느 인스턴스가 받아도 동작 → 오토스케일·인스턴스 교체에 안전
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))          # 컨테이너: common/ 이 같은 폴더에 복사됨
from common.he import DATASET, MODE, PROJECT, REGION, query, table  # noqa: E402

from mcp.server import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer(name="he-service-data", instructions="현대엘리베이터 AS·현장 데이터 조회 (읽기 전용). 긴 추출은 start → get_export_result.")
RO = ToolAnnotations(read_only_hint=True, open_world_hint=False)   # Gemini Enterprise는 읽기 전용이면 사용자 확인 생략


@mcp.tool(annotations=RO)
async def query_recurrence(min_recur: int = 3, region: str = "") -> dict:
    """현장별 30일 내 재발 건수 (2026년 3분기). region: 수도권·충청·호남·영남·강원 또는 빈 값."""
    sql = f"""SELECT s.site_id, s.site_name, s.region, s.model, s.installed_year, COUNTIF(t.recur_30d='Y') AS recur
              FROM {table('as_tickets')} t JOIN {table('sites')} s USING (site_id)
              WHERE (@region = '' OR s.region = @region)
              GROUP BY 1,2,3,4,5 HAVING recur >= @m ORDER BY recur DESC LIMIT 20"""
    rows = await asyncio.to_thread(query, sql, {"region": region, "m": int(min_recur)})
    return {"rows": rows, "basis": f"recur_30d='Y' >= {min_recur}, 지역={region or '전체'}"}


@mcp.tool(annotations=RO)
async def start_ticket_export(site_id: str) -> dict:
    """한 현장의 전체 AS 접수 내역 추출을 시작하고 job_id를 돌려줍니다. 결과는 get_export_result로 가져옵니다."""
    if MODE == "local":
        return {"job_id": f"local:{site_id}", "location": "local", "state": "RUNNING"}
    from google.cloud import bigquery
    from common.he import bq_client
    job = await asyncio.to_thread(
        bq_client().query,
        f"SELECT * FROM {table('as_tickets')} WHERE site_id = @s ORDER BY received_at",
        job_config=bigquery.QueryJobConfig(query_parameters=[bigquery.ScalarQueryParameter("s", "STRING", site_id)]))
    return {"job_id": job.job_id, "location": job.location, "state": job.state}


@mcp.tool(annotations=RO)
async def get_export_result(job_id: str, location: str = REGION, max_rows: int = 200) -> dict:
    """start_ticket_export 상태 확인. DONE이면 최대 max_rows행을 돌려줍니다. RUNNING이면 잠시 뒤 다시 호출하세요."""
    if job_id.startswith("local:"):
        rows = await asyncio.to_thread(query, f"SELECT * FROM {table('as_tickets')} WHERE site_id = @s ORDER BY received_at",
                                       {"s": job_id.split(":", 1)[1]})
        return {"state": "DONE", "total": len(rows), "rows": [{k: str(v) for k, v in r.items()} for r in rows[:max_rows]]}
    from common.he import bq_client
    job = await asyncio.to_thread(bq_client().get_job, job_id, location=location)
    if job.state != "DONE":
        return {"state": job.state}
    if job.error_result:
        return {"state": "ERROR", "error": job.error_result}
    res = await asyncio.to_thread(job.result, max_results=max_rows)
    return {"state": "DONE", "total": res.total_rows, "rows": [{k: str(v) for k, v in dict(r).items()} for r in res]}


if __name__ == "__main__":
    mcp.run(transport="streamable-http", host="0.0.0.0", port=int(os.getenv("PORT", "8080")),
            stateless_http=True, json_response=True)
