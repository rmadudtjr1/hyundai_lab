# he2-labs 저장소 규칙 (Antigravity·코딩 에이전트용)

- 설정 값(프로젝트 ID, 모델 ID, 버킷)은 `.env`와 `common/he.py`에서만 읽는다. 코드에 하드코딩하지 않는다.
- SQL은 BigQuery 문법으로 쓰고 `common.he.query()`로 실행한다. 사용자 입력은 문자열로 이어 붙이지 않고 @파라미터로 바인딩한다.
- BigQuery 실행에는 비용 상한(maximum_bytes_billed)을 둔다.
- 숫자 판정·비교는 파이썬 코드로 하고, 모델에게는 읽기·요약·작성만 맡긴다.
- `gcloud ... deploy`, `delete`, IAM 변경 명령은 실행하지 말고 명령만 제안한다.
- 테스트: `bash run_local_tests.sh` 가 통과해야 작업 완료로 본다.
