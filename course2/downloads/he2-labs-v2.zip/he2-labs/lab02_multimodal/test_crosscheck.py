"""모델 없이 판정 규칙만 시험합니다.  python test_crosscheck.py"""
from extract import cross_check, needs_review, review_mail
from schemas import Dimension, DrawingExtract, SpecExtract, SpecItem

plan = DrawingExtract(drawing_no="HE25-EL-101", view="plan", title="승강로 평면도", dimensions=[
    Dimension(name="승강로 폭", value_mm=2400, evidence="승강로 폭 2,400", confidence="high"),
    Dimension(name="승강로 깊이", value_mm=2250, evidence="승강로 깊이 2,250", confidence="high"),
    Dimension(name="출입구 폭", value_mm=900, evidence="출입구 폭 900", confidence="medium"),
    Dimension(name="카 내부 깊이", value_mm=1500, evidence="카 내부 깊이 1,500", confidence="low")])
section = DrawingExtract(drawing_no="HE25-EL-102", view="section", title="승강로 단면도", dimensions=[
    Dimension(name="피트 깊이", value_mm=1500, evidence="피트 깊이 1,500", confidence="high"),
    Dimension(name="오버헤드", value_mm=4600, evidence="오버헤드 4,600", confidence="high")])
spec = SpecExtract(items=[
    SpecItem(item="승강로 폭", value_text="2,400mm 이상", value_mm=2400, condition="min"),
    SpecItem(item="승강로 깊이", value_text="2,200mm 이상", value_mm=2200, condition="min"),
    SpecItem(item="피트 깊이", value_text="1,600mm 이상", value_mm=1600, condition="min"),
    SpecItem(item="오버헤드", value_text="4,500mm 이상", value_mm=4500, condition="min"),
    SpecItem(item="출입구 폭", value_text="900mm", value_mm=900, condition="exact"),
    SpecItem(item="카 내부 폭", value_text="1,800mm", value_mm=1800, condition="exact"),
    SpecItem(item="정격하중", value_text="1,150kg", value_mm=None, condition="none")])

res = {c["item"]: c["result"] for c in cross_check([plan, section], spec)}
assert res["피트 깊이"] == "부적합(사양 미달)", res
assert res["승강로 폭"] == "적합" and res["오버헤드"] == "적합" and res["출입구 폭"] == "일치"
assert res["카 내부 폭"] == "도면에 없음"          # 테스트 데이터에서 일부러 뺌
rv = needs_review(cross_check([plan, section], spec))
assert {c["item"] for c in rv} == {"피트 깊이", "카 내부 폭"}, rv
print("\n".join(f"{k}: {v}" for k, v in res.items()))
print("\n" + review_mail(rv, ["HE25-EL-101", "HE25-EL-102"]))
print("\nOK: 판정 규칙 테스트 통과")
