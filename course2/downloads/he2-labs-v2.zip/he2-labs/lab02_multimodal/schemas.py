"""lab02 출력 계약. 모델은 이 스키마대로만 답합니다 (response_json_schema).

치수 이름을 자유 텍스트로 받으면 '피트깊이', 'PIT 깊이'처럼 흔들려 비교가 깨집니다.
그래서 비교할 항목은 Literal(열거형)로 고정하고, 원문 표기는 evidence에 따로 받습니다.
"""
from typing import Literal, Optional
from pydantic import BaseModel, Field

DimName = Literal["승강로 폭", "승강로 깊이", "피트 깊이", "오버헤드", "카 내부 폭", "카 내부 깊이", "출입구 폭", "행정", "기타"]


class Dimension(BaseModel):
    name: DimName = Field(description="치수 항목. 목록에 없으면 '기타'")
    value_mm: Optional[float] = Field(description="mm 단위 숫자. 쉼표 제거. 읽을 수 없으면 null")
    evidence: str = Field(description="도면에 적힌 원문 표기 그대로. 예: '피트 깊이 1,500'")
    confidence: Literal["high", "medium", "low"] = Field(description="글자가 선과 겹치거나 흐리면 low")


class DrawingExtract(BaseModel):
    drawing_no: Optional[str] = Field(description="도면번호. 예: HE25-EL-101")
    revision: Optional[str] = None
    view: Literal["plan", "section", "elevation", "detail", "unknown"]
    title: str
    rated_load_kg: Optional[float] = None
    rated_speed_mpm: Optional[float] = None
    stops: Optional[int] = None
    dimensions: list[Dimension]
    unreadable: list[str] = Field(default_factory=list, description="읽지 못한 표기")


class SpecItem(BaseModel):
    item: DimName | Literal["정격하중", "정격속도", "정지층"]
    value_text: str = Field(description="사양서 원문. 예: '1,600mm 이상'")
    value_mm: Optional[float] = Field(description="치수 항목이면 mm 숫자, 아니면 null")
    condition: Literal["min", "max", "exact", "none"] = Field(description="이상=min, 이하=max, 단일값=exact")


class SpecExtract(BaseModel):
    doc_no: Optional[str] = None
    items: list[SpecItem]
