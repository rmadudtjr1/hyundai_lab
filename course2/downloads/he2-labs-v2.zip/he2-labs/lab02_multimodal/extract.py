"""lab02 · 도면·사양서 → JSON 추출 → 규칙 교차 검증.

python extract.py samples/drawing_plan.png samples/drawing_section.png samples/spec_sheet.pdf
결과: result.json (추출값, 교차 검증, 사람 검토 대상)
원칙: 읽기는 모델, 판정은 코드.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import MODEL_FAST, MODEL_PRO, genai_client  # noqa: E402
from schemas import DrawingExtract, SpecExtract  # noqa: E402

SYSTEM = ("당신은 승강기 설계 도면 판독자입니다. 보이는 표기만 옮기고 추측하지 않습니다. "
          "숫자의 쉼표는 제거하고 mm 단위로 적습니다. 글자가 선과 겹치거나 흐리면 confidence를 low로 둡니다.")


def _part(path: str):
    from google.genai import types
    data = Path(path).read_bytes()
    mime = "application/pdf" if path.lower().endswith(".pdf") else "image/png"
    if mime.startswith("image/"):
        # 작은 치수 글씨를 읽도록 이미지만 고해상도로 처리합니다 (파트 단위 지정)
        return types.Part.from_bytes(data=data, mime_type=mime, media_resolution=types.MediaResolution.MEDIA_RESOLUTION_HIGH)
    return types.Part.from_bytes(data=data, mime_type=mime)  # 텍스트 레이어가 있는 PDF는 기본값


def extract(path: str, schema, instruction: str, model: str = MODEL_FAST):
    from google.genai import types
    resp = genai_client().models.generate_content(
        model=model,
        contents=[_part(path), instruction],
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM,
            response_mime_type="application/json",
            response_json_schema=schema.model_json_schema(),
            temperature=0,
        ),
    )
    return schema.model_validate_json(resp.text)


def cross_check(drawings: list[DrawingExtract], spec: SpecExtract) -> list[dict]:
    """사양 조건(이상·이하·일치)과 도면 치수를 규칙으로 비교합니다. 모델은 관여하지 않습니다."""
    dims = {}
    for dr in drawings:
        for d in dr.dimensions:
            if d.name != "기타":
                dims.setdefault(d.name, d)
    out = []
    for it in spec.items:
        if it.value_mm is None or it.condition == "none":
            continue
        d = dims.get(it.item)
        if d is None:
            out.append({"item": it.item, "spec": it.value_text, "drawing": None, "result": "도면에 없음"})
            continue
        v = d.value_mm
        if v is None:
            res = "판독 불가"
        elif it.condition == "min":
            res = "적합" if v >= it.value_mm else "부적합(사양 미달)"
        elif it.condition == "max":
            res = "적합" if v <= it.value_mm else "부적합(사양 초과)"
        else:
            res = "일치" if abs(v - it.value_mm) < 1 else "불일치"
        out.append({"item": it.item, "spec": it.value_text, "drawing": d.evidence, "value_mm": v,
                    "result": res, "confidence": d.confidence})
    return out


def needs_review(checks: list[dict]) -> list[dict]:
    """사람이 볼 항목: 부적합·불일치·판독 불가·도면에 없음, 그리고 확신도 low."""
    bad = ("부적합", "불일치", "판독 불가", "도면에 없음")
    return [c for c in checks if c["result"].startswith(bad) or c.get("confidence") == "low"]


def review_mail(review: list[dict], drawing_nos: list[str]) -> str:
    """검토 요청 메일 본문 (발송은 사람이)."""
    lines = [f"[설계 검토 요청] {', '.join(n for n in drawing_nos if n)}", "",
             "도면-사양 자동 대조에서 아래 항목이 확인되어 검토를 요청드립니다.", ""]
    for c in review:
        lines.append(f"- {c['item']}: 사양 {c['spec']} / 도면 {c.get('drawing') or '없음'} → {c['result']}"
                     + (" (판독 확신도 낮음)" if c.get("confidence") == "low" else ""))
    lines += ["", "※ 자동 판독 결과이므로 원본 도면으로 확인 부탁드립니다."]
    return "\n".join(lines)


def main(paths: list[str]):
    drawings = [extract(p, DrawingExtract, "이 승강기 도면의 도면 정보와 모든 치수를 추출하세요.")
                for p in paths if not p.lower().endswith(".pdf")]
    spec = next((extract(p, SpecExtract, "이 사양서의 항목과 조건(이상/이하/단일값)을 추출하세요.")
                 for p in paths if p.lower().endswith(".pdf")), None)
    checks = cross_check(drawings, spec) if spec else []
    review = needs_review(checks)
    result = {"drawings": [d.model_dump() for d in drawings], "spec": spec.model_dump() if spec else None,
              "cross_check": checks, "needs_review": review,
              "review_mail": review_mail(review, [d.drawing_no for d in drawings]) if review else None}
    Path("result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    for c in checks:
        print(f"{c['item']:<8} 사양 {c['spec']:<14} 도면 {str(c.get('drawing')):<18} → {c['result']}")
    print(f"\n사람 검토 {len(review)}건 · result.json 저장")


if __name__ == "__main__":
    main(sys.argv[1:] or ["samples/drawing_plan.png", "samples/drawing_section.png", "samples/spec_sheet.pdf"])
