"""lab02 샘플 도면(PNG 2장)과 사양서(PDF) 생성. 이미 samples/에 들어 있으므로 다시 만들 때만 실행합니다.
의도적으로 '피트 깊이'가 사양(1,600 이상)보다 작게(1,500) 그려져 있습니다.
필요: pillow, playwright(PDF 생성용)
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).parent / "samples"; OUT.mkdir(exist_ok=True)
FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
f = lambda s: ImageFont.truetype(FONT, s, index=1)  # index 1 = KR


def dim_h(d, x1, x2, y, label, fnt):
    d.line([(x1, y), (x2, y)], fill="black", width=2)
    for x in (x1, x2):
        d.line([(x, y - 10), (x, y + 10)], fill="black", width=2)
    w = d.textlength(label, font=fnt); d.text(((x1 + x2 - w) / 2, y - 30), label, fill="black", font=fnt)


def dim_v(d, x, y1, y2, label, fnt):
    d.line([(x, y1), (x, y2)], fill="black", width=2)
    for y in (y1, y2):
        d.line([(x - 10, y), (x + 10, y)], fill="black", width=2)
    d.text((x + 14, (y1 + y2) / 2 - 12), label, fill="black", font=fnt)


def title_block(d, W, H, no, title, rev):
    d.rectangle([W - 620, H - 150, W - 20, H - 20], outline="black", width=2)
    d.text((W - 600, H - 140), f"도면번호  {no}   REV {rev}", fill="black", font=f(24))
    d.text((W - 600, H - 100), title, fill="black", font=f(24))
    d.text((W - 600, H - 60), "해솔타워 리모델링 · 승객용 1호기 · 축척 1:50", fill="black", font=f(20))


# 평면도
W, H = 1800, 1300
im = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(im)
d.rectangle([300, 250, 1300, 1000], outline="black", width=5)          # 승강로
d.rectangle([420, 340, 1180, 860], outline="black", width=3)           # 카
d.rectangle([600, 1000, 1000, 1030], fill="black")                      # 출입구
dim_h(d, 300, 1300, 200, "승강로 폭 2,400", f(26))
dim_v(d, 1360, 250, 1000, "승강로 깊이 2,250", f(26))
dim_h(d, 420, 1180, 900, "카 내부 폭 1,800", f(24))
dim_v(d, 360, 340, 860, "카 내부 깊이 1,500", f(22))
dim_h(d, 600, 1000, 1080, "출입구 폭 900", f(24))
d.text((320, 1140), "정격하중 1,150kg (17인승) · 정격속도 105m/min · 24정지", fill="black", font=f(26))
title_block(d, W, H, "HE25-EL-101", "승강로 평면도", "B")
im.save(OUT / "drawing_plan.png")

# 단면도
W, H = 1500, 1800
im = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(im)
d.rectangle([450, 150, 950, 1500], outline="black", width=5)
d.line([(450, 1350), (950, 1350)], fill="black", width=3)              # 최하층 바닥
d.line([(450, 300), (950, 300)], fill="black", width=3)                # 최상층 바닥
dim_v(d, 1000, 1350, 1500, "피트 깊이 1,500", f(26))
dim_v(d, 1000, 150, 300, "오버헤드 4,600", f(26))
dim_v(d, 380, 300, 1350, "", f(20)); d.text((150, 800), "행정 72,000", fill="black", font=f(26))
d.text((470, 1420), "완충기", fill="black", font=f(22))
title_block(d, W, H, "HE25-EL-102", "승강로 단면도", "B")
im.save(OUT / "drawing_section.png")

# 사양서 PDF
html = """<html><head><meta charset='utf-8'><style>body{font-family:'Noto Sans CJK KR';font-size:11pt}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #888;padding:5px 8px;text-align:left}th{background:#eee}</style></head><body>
<h2>승강기 기술 사양서 (해솔타워 리모델링 1호기)</h2><p>문서번호 HE25-SP-007 · 2026-10 · 교육용 가상 문서</p>
<table><tr><th>항목</th><th>사양</th><th>비고</th></tr>
<tr><td>정격하중</td><td>1,150kg (17인승)</td><td></td></tr>
<tr><td>정격속도</td><td>105m/min</td><td></td></tr>
<tr><td>정지층</td><td>24</td><td></td></tr>
<tr><td>승강로 폭</td><td>2,400mm 이상</td><td>내부 마감 기준</td></tr>
<tr><td>승강로 깊이</td><td>2,200mm 이상</td><td></td></tr>
<tr><td>피트 깊이</td><td>1,600mm 이상</td><td>완충기 행정 포함</td></tr>
<tr><td>오버헤드</td><td>4,500mm 이상</td><td></td></tr>
<tr><td>출입구 폭</td><td>900mm</td><td>중앙 개폐</td></tr>
<tr><td>카 내부 폭</td><td>1,800mm</td><td></td></tr></table>
<p>※ 도면 치수는 사양의 이상·이하 조건을 만족해야 하며, 불일치 시 설계 검토를 요청한다.</p></body></html>"""
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(); pg.set_content(html); pg.pdf(path=str(OUT / "spec_sheet.pdf"), format="A4"); b.close()
except ImportError:
    print("playwright가 없어 spec_sheet.pdf는 건너뜁니다.")
print("samples 생성 완료")
