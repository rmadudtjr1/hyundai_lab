"""lab03 · 시맨틱 레이어 기반 Text-to-SQL.

python nl2sql.py "2026년 3분기 해외 수주액은 몇 억원?"

① 스키마 연결 → ② Few-shot 선택 → ③ SQL 생성(JSON) → ④ 정적 검사·dry run, 실패 시 오류를 붙여 재생성
→ ⑤ 실행 → ⑥ 결과 행만 근거로 답변
"""
from __future__ import annotations

import json
import sys

from pydantic import BaseModel, Field

from semantic_layer import glossary, link_schema, few_shot, schemas
from sql_guard import check_sql
from common.he import DATASET, MODE, MODEL_FAST, MODEL_PRO, PROJECT, bq_client, genai_client, query, to_duckdb


class SqlAnswer(BaseModel):
    sql: str = Field(description="BigQuery 표준 SQL 한 문장. 테이블은 `프로젝트.데이터셋.테이블` 전체 이름")
    terms_used: list[str] = Field(description="사용한 용어사전 용어")
    assumptions: list[str] = Field(description="질문이 모호해서 둔 가정. 없으면 빈 목록")


def build_prompt(question: str, error: str | None = None) -> str:
    tables, terms = link_schema(question)
    sch = schemas()
    g = glossary()
    lines = ["당신은 BigQuery SQL 작성자입니다. 아래 스키마·용어사전·규칙만 사용합니다.", "", "## 테이블"]
    for t in tables:
        s = sch[t]
        lines.append(f"`{PROJECT or 'local'}.{DATASET}.{t}` -- {s['description']}")
        lines += [f"  - {f['name']} {f['type']}: {f['description']}" for f in s["fields"]]
    lines += ["", "## 용어사전 (이 계산식을 그대로 씀)"]
    for t in (terms or g["terms"]):
        lines.append(f"- {t['term']}: {t.get('definition', '')} → {t['expr']}")
    lines += ["", "## 규칙"] + [f"- {r}" for r in g["rules"]] + [f"- 관계: {r}" for r in g["relationships"]]
    lines += ["", "## 검증된 예시"]
    for ex in few_shot(question):
        lines += [f"질문: {ex['question']}", f"SQL: {ex['sql'].strip()}", ""]
    if error:
        lines += ["## 직전 시도가 실패했습니다. 오류를 고쳐 다시 작성하세요.", error, ""]
    lines += [f"## 질문\n{question}"]
    return "\n".join(lines)


def dry_run(sql: str) -> int:
    """실행하지 않고 검증합니다. BigQuery는 처리 바이트를, local 모드는 DuckDB EXPLAIN 성공 여부를 봅니다."""
    if MODE == "local":
        from common.he import _duck
        _duck().execute("EXPLAIN " + to_duckdb(sql))
        return 0
    from google.cloud import bigquery
    job = bq_client().query(sql, job_config=bigquery.QueryJobConfig(dry_run=True, use_query_cache=False))
    if job.total_bytes_processed > 5 * 10**9:
        raise ValueError(f"처리량 {job.total_bytes_processed/1e9:.1f}GB가 상한 5GB를 넘습니다.")
    return job.total_bytes_processed


def generate_sql(question: str, max_attempts: int = 3) -> tuple[SqlAnswer, int]:
    from google.genai import types
    error = None
    for attempt in range(1, max_attempts + 1):
        resp = genai_client().models.generate_content(
            model=MODEL_PRO, contents=build_prompt(question, error),
            config=types.GenerateContentConfig(response_mime_type="application/json",
                                               response_json_schema=SqlAnswer.model_json_schema(), temperature=0))
        ans = SqlAnswer.model_validate_json(resp.text)
        ok, msg = check_sql(ans.sql)
        if not ok:
            error = f"[정적 검사 {attempt}회차] {msg}\nSQL: {ans.sql}"
            continue
        try:
            return ans, dry_run(ans.sql)
        except Exception as e:  # BigQuery·DuckDB 오류 메시지를 그대로 붙여 다시 생성 (자기 수정)
            error = f"[dry run {attempt}회차] {e}\nSQL: {ans.sql}"
    raise RuntimeError(f"{max_attempts}회 시도 후 실패\n{error}")


def answer(question: str) -> dict:
    from google.genai import types
    ans, nbytes = generate_sql(question)
    rows = query(ans.sql)
    text = genai_client().models.generate_content(
        model=MODEL_FAST,
        contents=(f"질문: {question}\n결과 행(JSON): {json.dumps(rows[:50], ensure_ascii=False, default=str)}\n"
                  f"가정: {ans.assumptions}\n결과 행에 있는 숫자만 써서 2~3문장으로 답하고, 가정이 있으면 밝히세요."),
        config=types.GenerateContentConfig(temperature=0)).text
    return {"sql": ans.sql, "terms": ans.terms_used, "assumptions": ans.assumptions, "bytes": nbytes, "rows": rows, "answer": text}


if __name__ == "__main__":
    q = " ".join(sys.argv[1:]) or "2026년 3분기 해외 수주액은 몇 억원?"
    r = answer(q)
    print("SQL:\n" + r["sql"]); print("용어:", r["terms"], "가정:", r["assumptions"])
    print("결과:", json.dumps(r["rows"][:10], ensure_ascii=False, default=str)); print("\n답변:", r["answer"])
