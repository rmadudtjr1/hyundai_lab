"""실행 정확도 평가: 생성 SQL의 결과 == 정답 SQL의 결과 (값만 비교, 열 이름·행 순서 무시, 소수 1자리).

python evaluate.py              # 전체
python evaluate.py Q2 Q4        # 일부
용어사전·지시문을 고칠 때마다 다시 돌려 점수 변화를 기록합니다.
"""
import json, sys, time
from nl2sql import generate_sql
from semantic_layer import eval_set
from common.he import query


def norm(rows):
    out = []
    for r in rows:
        vals = []
        for v in r.values():
            try: vals.append(round(float(v), 1))
            except (TypeError, ValueError): vals.append(str(v))
        out.append(tuple(vals))
    return sorted(out, key=str)


def main(ids):
    cases = [c for c in eval_set() if not ids or c["id"] in ids]
    log, passed = [], 0
    for c in cases:
        t0 = time.time()
        try:
            ans, _ = generate_sql(c["question"])
            ok = norm(query(ans.sql)) == norm(query(c["gold"]))
            sql, err = ans.sql, None
        except Exception as e:
            ok, sql, err = False, None, str(e)[:300]
        passed += ok
        print(f"{'PASS' if ok else 'FAIL'}  {c['id']}  {c['question']}  ({time.time()-t0:.1f}s)")
        log.append({"id": c["id"], "pass": ok, "sql": sql, "error": err})
    print(f"\n실행 정확도 {passed}/{len(cases)}")
    json.dump(log, open("eval_log.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(sys.argv[1:])
