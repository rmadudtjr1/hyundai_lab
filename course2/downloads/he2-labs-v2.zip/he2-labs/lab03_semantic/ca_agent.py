"""관리형 Conversational Analytics API 데이터 에이전트에 같은 시맨틱 자산을 넣기.

python ca_agent.py create                      # 에이전트 생성 (용어사전·검증 쿼리 포함)
python ca_agent.py ask "권역별 갇힘 도착 준수율"   # 질문 → SQL·결과·차트 사양(Vega-Lite)
필요: geminidataanalytics.googleapis.com, roles/geminidataanalytics.dataAgentCreator, BigQuery 읽기 권한
"""
import sys
from google.cloud import geminidataanalytics as ga
from semantic_layer import ALLOWED_TABLES, glossary, verified
from common.he import DATASET, PROJECT

LOC = "global"
AGENT_ID = "he-ax-metrics"
PARENT = f"projects/{PROJECT}/locations/{LOC}"


def build_context() -> ga.Context:
    g = glossary()
    rules = "\n".join(f"- {r}" for r in g["rules"])
    return ga.Context(
        system_instruction=f"당신은 현대엘리베이터 경영지표 분석가입니다.\n{rules}",
        datasource_references=ga.DatasourceReferences(bq=ga.BigQueryTableReferences(table_references=[
            ga.BigQueryTableReference(project_id=PROJECT, dataset_id=DATASET, table_id=t) for t in sorted(ALLOWED_TABLES)])),
        glossary_terms=[ga.GlossaryTerm(display_name=t["term"], description=f"{t.get('definition', '')} 계산식: {t['expr']}",
                                        labels=t.get("synonyms", [])) for t in g["terms"]],
        example_queries=[ga.ExampleQuery(natural_language_question=v["question"], sql_query=v["sql"]) for v in verified()],
    )


def create():
    agent = ga.DataAgent(display_name="현대엘리베이터 경영지표 에이전트",
                         data_analytics_agent=ga.DataAnalyticsAgent(published_context=build_context()))
    op = ga.DataAgentServiceClient().create_data_agent(
        request=ga.CreateDataAgentRequest(parent=PARENT, data_agent_id=AGENT_ID, data_agent=agent))
    print("생성:", op.result().name)


def ask(question: str):
    chat = ga.DataChatServiceClient()
    req = ga.ChatRequest(parent=PARENT,
                         messages=[ga.Message(user_message=ga.UserMessage(text=question))],
                         data_agent_context=ga.DataAgentContext(data_agent=f"{PARENT}/dataAgents/{AGENT_ID}"))
    for resp in chat.chat(request=req):          # 스트리밍 응답: 텍스트·SQL·데이터·차트가 나뉘어 옴
        m = resp.system_message
        if m.text and m.text.parts: print("[텍스트]", " ".join(m.text.parts))
        if m.data:
            if m.data.generated_sql: print("[SQL]", m.data.generated_sql)
            if m.data.matched_query: print("[검증 쿼리 일치]", m.data.matched_query)
        if m.chart and m.chart.result and m.chart.result.vega_config: print("[차트] Vega-Lite 사양 수신")


if __name__ == "__main__":
    {"create": lambda: create(), "ask": lambda: ask(" ".join(sys.argv[2:]))}[sys.argv[1]]()
