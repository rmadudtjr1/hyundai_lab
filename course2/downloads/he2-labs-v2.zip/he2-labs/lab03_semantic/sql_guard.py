"""생성된 SQL을 실행 전에 정적으로 검사합니다. 통과하지 못하면 실행하지 않고 오류를 모델에게 돌려줍니다."""
import sqlglot
from sqlglot import exp

from semantic_layer import ALLOWED_TABLES

FORBIDDEN = (exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter, exp.Merge, exp.Command)


def check_sql(sql: str) -> tuple[bool, str]:
    try:
        trees = [t for t in sqlglot.parse(sql, read="bigquery") if t is not None]
    except Exception as e:
        return False, f"구문 오류: {e}"
    if len(trees) != 1:
        return False, "SQL 문은 하나만 허용합니다."
    tree = trees[0]
    for bad in FORBIDDEN:
        if isinstance(tree, bad) or tree.find(bad):
            return False, f"허용되지 않는 구문: {bad.__name__}"
    if not (isinstance(tree, (exp.Select, exp.Union)) or tree.find(exp.Select)):
        return False, "SELECT 문만 허용합니다."
    ctes = {c.alias_or_name for c in tree.find_all(exp.CTE)}
    for t in tree.find_all(exp.Table):
        if t.name not in ALLOWED_TABLES and t.name not in ctes:
            return False, f"허용되지 않은 테이블: {t.name} (허용: {', '.join(sorted(ALLOWED_TABLES))})"
    if tree.find(exp.Star) and not tree.find(exp.Group) and not tree.args.get("limit"):
        return False, "SELECT * 는 LIMIT 없이 쓸 수 없습니다."
    return True, "ok"
