"""정적 검사·스키마 연결·정답 SQL을 LLM 없이 확인합니다.  LAB_MODE=local python test_guard.py"""
import os; os.environ.setdefault("LAB_MODE", "local")
from sql_guard import check_sql
from semantic_layer import eval_set, link_schema, verified
from common.he import query

cases = [
    ("SELECT region, SUM(amount_mkrw) FROM `p.he_ax.orders` GROUP BY region", True),
    ("DELETE FROM `p.he_ax.orders` WHERE TRUE", False),
    ("SELECT * FROM `p.he_ax.salary`", False),
    ("SELECT 1; DROP TABLE x", False),
    ("SELECT * FROM `p.he_ax.cost_detail`", False),
    ("SELECT * FROM `p.he_ax.orders`", False),
    ("WITH w AS (SELECT * FROM `p.he_ax.orders` WHERE stage='WON') SELECT region, COUNT(*) FROM w GROUP BY 1", True),
]
for sql, expect in cases:
    ok, msg = check_sql(sql)
    assert ok == expect, (sql, msg); print(("PASS " if ok else "BLOCK"), "|", msg, "|", sql[:60])
print("스키마 연결:", link_schema("2026년 3분기 리모델링 영업이익률은?")[0], link_schema("권역별 갇힘 도착 준수율")[0])
for v in verified(): assert check_sql(v["sql"])[0], v["question"]; query(v["sql"])
print("\n정답 SQL 결과 (강사용):")
for q in eval_set():
    assert check_sql(q["gold"])[0]
    print(q["id"], q["question"], "→", query(q["gold"]))
print("\nOK")
