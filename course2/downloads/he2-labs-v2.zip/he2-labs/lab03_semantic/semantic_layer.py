"""시맨틱 레이어 자산 읽기: 열 설명(00_setup/schema), 용어사전, 검증 쿼리, 평가 세트."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
from common.he import DATASET, PROJECT, ROOT  # noqa: E402

SCHEMA_DIR = ROOT / "00_setup" / "schema"
ALLOWED_TABLES = {"sites", "as_tickets", "orders", "pl_monthly"}   # cost_detail은 04장 전용, 여기선 차단


def fill(sql: str) -> str:
    return sql.replace("{P}", PROJECT or "local").replace("{D}", DATASET)


def schemas() -> dict[str, dict]:
    return {t: json.loads((SCHEMA_DIR / f"{t}.json").read_text(encoding="utf-8")) for t in sorted(ALLOWED_TABLES)}


def glossary() -> dict:
    return yaml.safe_load((HERE / "semantic" / "glossary.yaml").read_text(encoding="utf-8"))


def verified() -> list[dict]:
    return [{**q, "sql": fill(q["sql"])} for q in yaml.safe_load((HERE / "semantic" / "verified_queries.yaml").read_text(encoding="utf-8"))]


def eval_set() -> list[dict]:
    return [{**q, "gold": fill(q["gold"])} for q in yaml.safe_load((HERE / "semantic" / "eval_set.yaml").read_text(encoding="utf-8"))]


def link_schema(question: str) -> tuple[list[str], list[dict]]:
    """질문에 나온 용어(동의어 포함)로 관련 용어 정의와 테이블을 고릅니다. 못 찾으면 전체 테이블."""
    g = glossary()
    hits = [t for t in g["terms"] if any(w in question for w in [t["term"], *t.get("synonyms", [])])]
    tables = sorted({tb for t in hits for tb in t["tables"]})
    kw = {"현장": "sites", "권역": "sites", "모델별": "sites", "HM-": "sites", "AS": "as_tickets", "고장": "as_tickets", "갇힘": "as_tickets",
          "수주": "orders", "실주": "orders", "경쟁사": "orders", "매출": "pl_monthly", "원가": "pl_monthly", "손익": "pl_monthly"}
    tables = sorted(set(tables) | {t for k, t in kw.items() if k in question}) or sorted(ALLOWED_TABLES)
    if "as_tickets" in tables and any(w in question for w in ["권역", "지역", "모델별", "설치"]):
        tables = sorted(set(tables) | {"sites"})
    return tables, hits


def _bigrams(s: str) -> set[str]:
    s = s.replace(" ", "")
    return {s[i:i + 2] for i in range(len(s) - 1)}


def few_shot(question: str, k: int = 2) -> list[dict]:
    """문자 2-gram 겹침으로 가장 비슷한 검증 쿼리 k개 (실무에선 임베딩 유사도로 바꿉니다)."""
    q = _bigrams(question)
    return sorted(verified(), key=lambda v: -len(q & _bigrams(v["question"])))[:k]
