"""LLM 없이 도구·콜백·그래프를 확인합니다.  LAB_MODE=local python test_local.py"""
import asyncio, json, os, sys
os.environ.setdefault("LAB_MODE", "local")
sys.path.insert(0, os.path.dirname(__file__))
from as_agent.agent import query_recurrence, get_site_history, block_pii, root_agent
from proposal_flow.agent import fetch_facts, root_agent as flow
from google.adk.models import LlmRequest
from google.genai import types

r = query_recurrence(min_recur=10)
assert r["rows"][0]["site_name"] == "해솔타워" and r["rows"][0]["recur"] == 18, r["rows"][:2]
print("query_recurrence OK:", [(x["site_name"], x["recur"]) for x in r["rows"]])
assert get_site_history("광화문")["status"] == "not_found"
print("get_site_history not_found OK, 해솔타워", len(get_site_history("해솔")["rows"]), "건")

req = LlmRequest(contents=[types.Content(role="user", parts=[types.Part(text="900101-1234567 고객 이력 알려줘")])])
assert block_pii(None, req) is not None
req2 = LlmRequest(contents=[types.Content(role="user", parts=[types.Part(text="해솔타워 이력")])])
assert block_pii(None, req2) is None
print("block_pii OK")

facts = json.loads(fetch_facts(None)); print("fetch_facts OK:", facts["recur_top5"][0])
print("tools:", [getattr(t, "name", getattr(t, "__name__", t)) for t in root_agent.tools])
print("workflow nodes:", [n.name for n in flow.graph.nodes])
