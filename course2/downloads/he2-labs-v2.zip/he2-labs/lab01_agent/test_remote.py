"""배포된 에이전트에 질문 1개 보내기.  python test_remote.py projects/.../reasoningEngines/ID"""
import asyncio, os, sys
import vertexai

async def main(name: str):
    client = vertexai.Client(project=os.environ["GOOGLE_CLOUD_PROJECT"], location=name.split("/")[3])
    app = client.agent_engines.get(name=name)
    async for ev in app.async_stream_query(user_id="tester", message="영남 재발 3건 이상 현장 보여 줘"):
        for p in (ev.get("content") or {}).get("parts", []):
            if "text" in p: print(p["text"], end="")
            if "function_call" in p: print(f"\n[도구 호출] {p['function_call']['name']} {p['function_call'].get('args')}")
    print()

asyncio.run(main(sys.argv[1]))
