"""lab01 · AS 재발 조회 에이전트 (ADK 2.x).

노코드(Workflow Builder)로 어려운 부분을 코드로 보여 줍니다.
- 파라미터 바인딩 SQL 도구 (비용 상한 포함)
- 모델 호출 전 개인정보 차단 콜백, 도구 호출 감사 로그 콜백
- 다른 에이전트를 도구로 부르기 (AgentTool)
"""
from __future__ import annotations

import json
import logging
import re
import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # 로컬: he2-labs 루트
sys.path.insert(0, str(Path(__file__).resolve().parent))      # 배포: deploy.sh가 common/을 복사해 둠
from common.he import MODEL_FAST, MODEL_PRO, query, table  # noqa: E402

from google.adk.agents import LlmAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from google.adk.tools import AgentTool
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

log = logging.getLogger("as_agent")


# ---------------------------------------------------------------- 도구
def query_recurrence(min_recur: int = 3, region: str = "") -> dict:
    """현장별 30일 내 재발 건수를 조회합니다 (2026년 3분기).

    Args:
        min_recur: 이 값 이상 재발한 현장만 반환합니다.
        region: 지역 필터(수도권, 충청, 호남, 영남, 강원). 빈 문자열이면 전체.
    """
    sql = f"""
      SELECT s.site_id, s.site_name, s.region, s.model, s.installed_year,
             COUNT(*) AS tickets, COUNTIF(t.recur_30d = 'Y') AS recur
      FROM {table('as_tickets')} t
      JOIN {table('sites')} s USING (site_id)
      WHERE (@region = '' OR s.region = @region)
      GROUP BY 1, 2, 3, 4, 5
      HAVING recur >= @min_recur
      ORDER BY recur DESC
      LIMIT 20"""
    rows = query(sql, {"region": region, "min_recur": int(min_recur)})
    return {"status": "success", "rows": rows,
            "basis": f"recur_30d='Y' 건수 >= {min_recur}, 지역={region or '전체'}, 2026-07~09"}


def get_site_history(site_name: str) -> dict:
    """한 현장의 AS 접수 이력을 시간순으로 돌려줍니다.

    Args:
        site_name: 현장명 (예: 해솔타워). 일부만 써도 됩니다.
    """
    sql = f"""
      SELECT t.received_at, t.fault_code, t.symptom, t.arrival_min, t.status, t.recur_30d,
             s.site_name, s.model, s.installed_year
      FROM {table('as_tickets')} t JOIN {table('sites')} s USING (site_id)
      WHERE s.site_name LIKE CONCAT('%', @name, '%')
      ORDER BY t.received_at"""
    rows = query(sql, {"name": site_name})
    if not rows:
        return {"status": "not_found", "message": f"'{site_name}' 현장은 데이터에 없습니다."}
    return {"status": "success", "rows": [{k: str(v) for k, v in r.items()} for r in rows]}


# ---------------------------------------------------------------- 콜백 (가드레일·감사)
PII = re.compile(r"\d{6}-?[1-4]\d{6}|01[016-9]-?\d{3,4}-?\d{4}")


def block_pii(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
    """주민등록번호·휴대전화 번호가 들어간 요청은 모델에 보내지 않습니다."""
    last = llm_request.contents[-1] if llm_request.contents else None
    text = " ".join(p.text or "" for p in (last.parts or [])) if last else ""
    if PII.search(text):
        return LlmResponse(content=types.Content(role="model", parts=[types.Part(
            text="개인정보(주민등록번호·전화번호)가 포함된 요청은 처리하지 않습니다. 해당 정보를 지우고 다시 요청해 주세요.")]))
    return None  # None을 돌려주면 원래대로 모델을 호출합니다


def audit_tool(tool: BaseTool, args: dict, tool_context: ToolContext) -> Optional[dict]:
    """도구 호출을 JSON 한 줄로 남깁니다 (Cloud Logging에서 검색)."""
    log.warning(json.dumps({"event": "tool_call", "tool": tool.name, "args": args,
                            "user": getattr(tool_context, "user_id", None)}, ensure_ascii=False))
    if tool.name == "query_recurrence" and int(args.get("min_recur", 3)) < 1:
        return {"status": "error", "message": "min_recur는 1 이상이어야 합니다."}  # 도구를 실행하지 않고 바로 응답
    return None


# ---------------------------------------------------------------- 에이전트
proposal_writer = LlmAgent(
    name="proposal_writer",
    model=MODEL_PRO,
    description="재발 데이터를 받아 영업팀에 보낼 리모델링 제안 메모를 쓰는 에이전트",
    instruction=("당신은 승강기 리모델링 제안 메모 작성자입니다.\n"
                 "입력으로 받은 재발 현장 데이터만 근거로 메모를 씁니다. 숫자를 새로 만들지 않습니다.\n"
                 "형식: 제목 1줄 / 대상 현장 표 / 제안 근거 3줄 / 요청 사항. 추정은 (추정)으로 표시합니다."),
)

root_agent = LlmAgent(
    name="as_root",
    model=MODEL_FAST,
    description="AS 재발 조회와 리모델링 제안 도우미",
    instruction=("당신은 승강기 서비스 데이터 도우미입니다.\n"
                 "- 재발 현장, 현장 이력 같은 조회는 도구를 직접 호출해 표로 답하고, 도구가 돌려준 basis를 한 줄로 밝힙니다.\n"
                 "- '제안 메모', '영업팀 보고'처럼 문서가 필요하면 먼저 query_recurrence로 데이터를 얻은 뒤 proposal_writer 도구에 넘깁니다.\n"
                 "- 안전 판정(운행 가능 여부)은 하지 않고 현장 기사 판단이 필요하다고 안내합니다.\n"
                 "- 도구 결과에 없는 숫자는 쓰지 않습니다."),
    tools=[query_recurrence, get_site_history, AgentTool(agent=proposal_writer)],
    before_model_callback=block_pii,
    before_tool_callback=audit_tool,
)
