#!/usr/bin/env bash
# Agent Runtime(구 Agent Engine)에 배포. CLI 명령 이름은 아직 agent_engine 입니다.
# 사용: PROJECT_ID=he-ax-lab-team1 bash deploy.sh  (기존 배포 갱신은 ENGINE_ID=... 추가)
set -euo pipefail
: "${PROJECT_ID:?PROJECT_ID 필요}"
RUNTIME_REGION="${RUNTIME_REGION:-asia-northeast3}"   # Agent Runtime은 global 미지원. 서울 리전 제공
rm -rf as_agent/common && cp -r ../common as_agent/common   # 배포 패키지에 공통 모듈 포함
adk deploy agent_engine \
  --project="$PROJECT_ID" --region="$RUNTIME_REGION" \
  --display_name="AS 재발 조회 도우미" \
  --description="AS 재발 조회와 리모델링 제안" \
  --trace_to_cloud \
  ${ENGINE_ID:+--agent_engine_id="$ENGINE_ID"} \
  as_agent
# 출력의 projects/.../reasoningEngines/ID 를 복사해 test_remote.py, register_ge.sh 에 씁니다.
