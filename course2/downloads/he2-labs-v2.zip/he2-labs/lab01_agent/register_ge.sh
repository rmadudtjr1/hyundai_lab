#!/usr/bin/env bash
# Gemini Enterprise 앱에 ADK 에이전트 등록 (v1alpha). 필요 권한: Gemini Enterprise Admin.
# 콘솔로 하려면: Gemini Enterprise → 앱 → Agents → Add agent → Custom agent via Agent Runtime
# 사용: PROJECT_ID=... APP_ID=... ENGINE=projects/.../locations/asia-northeast3/reasoningEngines/123 bash register_ge.sh
set -euo pipefail
: "${PROJECT_ID:?}" "${APP_ID:?}" "${ENGINE:?}"
GE_LOC="${GE_LOC:-global}"            # 앱 위치. global 앱은 어느 리전 엔진이든 등록 가능
HOST=$([ "$GE_LOC" = global ] && echo "discoveryengine.googleapis.com" || echo "${GE_LOC}-discoveryengine.googleapis.com")
curl -sS -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -H "X-Goog-User-Project: ${PROJECT_ID}" \
  "https://${HOST}/v1alpha/projects/${PROJECT_ID}/locations/${GE_LOC}/collections/default_collection/engines/${APP_ID}/assistants/default_assistant/agents" \
  -d @- <<JSON
{
  "displayName": "AS 재발 조회 도우미",
  "description": "현장별 AS 재발을 조회하고 리모델링 제안 메모를 씁니다. 안전 판정은 하지 않습니다.",
  "adkAgentDefinition": {
    "provisionedReasoningEngine": { "reasoningEngine": "${ENGINE}" }
  }
}
JSON
# Standard 라이선스는 에이전트 생성이 하루 1건입니다. 넘으면 429.
