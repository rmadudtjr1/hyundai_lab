"""lab01 · 그래프 워크플로 (ADK 2.x Workflow).

ADK 2.x에서 SequentialAgent·ParallelAgent·LoopAgent는 deprecated이고 Workflow가 권장됩니다.
결정적인 단계(데이터 조회)는 파이썬 함수 노드로, 판단·작성만 LLM 노드로 둡니다.

START → fetch_facts(함수) → analyst(LLM) → writer(LLM)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # 로컬: he2-labs 루트
sys.path.insert(0, str(Path(__file__).resolve().parent))      # 배포: deploy.sh가 common/을 복사해 둠
from common.he import MODEL_FAST, MODEL_PRO, query, table  # noqa: E402

from google.adk import Workflow
from google.adk.agents import LlmAgent


def fetch_facts(node_input) -> str:
    """재발 상위 현장과 해당 지역 수주 실적을 SQL로 가져옵니다. LLM을 쓰지 않으므로 항상 같은 결과."""
    recur = query(f"""
      SELECT s.site_name, s.region, s.model, s.installed_year, COUNTIF(t.recur_30d='Y') AS recur
      FROM {table('as_tickets')} t JOIN {table('sites')} s USING (site_id)
      GROUP BY 1,2,3,4 ORDER BY recur DESC LIMIT 5""")
    won = query(f"""
      SELECT region, ROUND(SUM(amount_mkrw),1) AS won_mkrw, COUNTIF(stage='LOST') AS lost
      FROM {table('orders')}
      WHERE order_date BETWEEN '2026-07-01' AND '2026-09-30' AND stage IN ('WON','LOST')
      GROUP BY region ORDER BY region""")
    return json.dumps({"recur_top5": recur, "q3_orders_by_region": won}, ensure_ascii=False, default=str)


analyst = LlmAgent(
    name="analyst",
    model=MODEL_FAST,
    instruction=("입력 JSON(재발 상위 현장, 지역별 3분기 수주)을 읽고 리모델링 영업 우선순위 3곳을 고르세요.\n"
                 "각 현장마다 근거 숫자를 함께 적고, 데이터에 없는 사실은 쓰지 마세요."),
    output_key="analysis",
)

writer = LlmAgent(
    name="writer",
    model=MODEL_PRO,
    instruction=("앞 단계 분석을 바탕으로 영업본부장 보고 메모를 쓰세요.\n"
                 "분석 내용: {analysis?}\n"
                 "형식: 제목 / 요약 3줄 / 우선순위 표 / 요청 사항. 10줄 안팎."),
)

root_agent = Workflow(name="proposal_flow", edges=[("START", fetch_facts, analyst, writer)])
