#!/usr/bin/env bash
# Cloud Run 작업 + Cloud Scheduler(매일 07:30 KST) + 실패 알림
# 사용: PROJECT_ID=he-ax-lab-team1 bash deploy.sh
set -euo pipefail
: "${PROJECT_ID:?}"; REGION="${REGION:-asia-northeast3}"
SA="he-lab-runner@${PROJECT_ID}.iam.gserviceaccount.com"
rm -rf common && cp -r ../common common

# 1) 작업: 권역 5개를 태스크 5개로 병렬, 태스크당 최대 30분, 실패 태스크만 3회 재시도
gcloud run jobs deploy as-daily --source . --project "$PROJECT_ID" --region "$REGION" \
  --tasks 5 --parallelism 5 --max-retries 3 --task-timeout 30m \
  --service-account "$SA" \
  --set-env-vars "GOOGLE_CLOUD_PROJECT=${PROJECT_ID},REGION=${REGION},OUT_BUCKET=${PROJECT_ID}-he-lab,GOOGLE_CLOUD_LOCATION=global"

# 2) 예약: Scheduler가 Cloud Run Admin API의 jobs.run 호출 (OAuth 토큰)
gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:$SA" --role=roles/run.invoker --condition=None >/dev/null
gcloud scheduler jobs create http as-daily-0730 --project "$PROJECT_ID" --location "$REGION" \
  --schedule "30 7 * * *" --time-zone "Asia/Seoul" \
  --uri "https://run.googleapis.com/v2/projects/${PROJECT_ID}/locations/${REGION}/jobs/as-daily:run" \
  --http-method POST --oauth-service-account-email "$SA" 2>/dev/null \
|| gcloud scheduler jobs update http as-daily-0730 --project "$PROJECT_ID" --location "$REGION" --schedule "30 7 * * *" --time-zone "Asia/Seoul"

# 3) 실패 알림: 실패한 실행이 1건이라도 생기면 알림 (알림 채널은 콘솔에서 만들어 ID를 넣으세요)
if [ -n "${CHANNEL:-}" ]; then
  sed "s#CHANNEL_ID#${CHANNEL}#" alert_policy.json > /tmp/alert.json
  gcloud monitoring policies create --project "$PROJECT_ID" --policy-from-file=/tmp/alert.json
fi
echo "수동 실행: gcloud run jobs execute as-daily --region $REGION --update-env-vars RUN_DATE=2026-09-30"
