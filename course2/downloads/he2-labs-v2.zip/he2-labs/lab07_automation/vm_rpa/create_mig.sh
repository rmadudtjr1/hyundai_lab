#!/usr/bin/env bash
# Windows 전용 데스크톱 RPA처럼 컨테이너로 못 옮기는 경우: VM 1대를 관리형 인스턴스 그룹(MIG)으로 운영
#  - VM이 죽거나 헬스 체크에 실패하면 MIG가 다시 만듦(자동 복구)
#  - 다시 만들면 부트 디스크가 템플릿에서 새로 생기므로, RPA 상태·결과는 GCS·DB에 둡니다
set -euo pipefail
: "${PROJECT_ID:?}"; ZONE="${ZONE:-asia-northeast3-a}"
gcloud compute instance-templates create rpa-win-tpl --project "$PROJECT_ID" \
  --machine-type e2-standard-4 --image-family windows-2022 --image-project windows-cloud \
  --boot-disk-size 100GB --no-address --service-account "he-lab-runner@${PROJECT_ID}.iam.gserviceaccount.com" \
  --scopes cloud-platform --metadata-from-file windows-startup-script-ps1=startup.ps1
gcloud compute health-checks create http rpa-hc --project "$PROJECT_ID" --port 8080 --request-path /healthz \
  --check-interval 30s --unhealthy-threshold 3
gcloud compute instance-groups managed create rpa-mig --project "$PROJECT_ID" --zone "$ZONE" \
  --template rpa-win-tpl --size 1 --health-check rpa-hc --initial-delay 600
# 헬스 체크 프로브 대역(35.191.0.0/16 등)에서 8080 허용 방화벽 규칙이 필요합니다.
