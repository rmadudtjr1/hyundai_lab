# Windows 시작 스크립트: RPA 에이전트 실행 + /healthz 응답 (예시)
# 실제 RPA 도구 설치·라이선스 등록은 도구 공급사 안내에 따릅니다.
Start-Process -FilePath "C:\rpa\agent.exe" -ArgumentList "--headless" -WindowStyle Hidden
# 간단 헬스 체크: RPA 프로세스가 살아 있으면 200
$l = New-Object System.Net.HttpListener; $l.Prefixes.Add("http://+:8080/healthz/"); $l.Start()
while ($l.IsListening) { $c = $l.GetContext(); $ok = Get-Process agent -ErrorAction SilentlyContinue
  $c.Response.StatusCode = $(if ($ok) {200} else {500}); $c.Response.Close() }
