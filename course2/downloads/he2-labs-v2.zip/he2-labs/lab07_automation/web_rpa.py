"""API가 없는 웹 화면을 다루는 RPA를 컨테이너에서 실행하는 예 (Playwright, 헤드리스).
로컬 PC RPA에서 옮길 때: 좌표 클릭 대신 '텍스트·역할' 선택자, 화면 변경 시 스크린샷 남기고 예외로 종료(→ 재시도·알림).
Dockerfile: FROM mcr.microsoft.com/playwright/python:v1.55.0-noble  (pip install playwright 버전과 맞춤)
"""
import os, sys
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

URL = os.getenv("PORTAL_URL", "https://example.com/")


def run():
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        try:
            pg.goto(URL, timeout=30_000)
            title = pg.get_by_role("heading").first.inner_text(timeout=10_000)   # 역할·텍스트 기반 선택자
            print({"severity": "INFO", "message": "portal ok", "heading": title})
        except PWTimeout:
            pg.screenshot(path="/tmp/rpa_fail.png", full_page=True)
            print({"severity": "ERROR", "message": "화면 구조가 바뀌었거나 응답 없음"}); sys.exit(1)
        finally:
            b.close()


if __name__ == "__main__":
    run()
