"""lab07 · 무중단 자동화: 매일 아침 권역별 AS 현황 요약 (Cloud Run 작업).

로컬:  LAB_MODE=local SKIP_LLM=1 RUN_DATE=2026-09-30 python main.py
배포 후: Cloud Scheduler가 매일 07:30 실행. 작업 1개 = 태스크 5개(권역별 병렬), 실패 태스크만 최대 3회 재시도.

원칙
- 멱등성: 같은 기준일·권역 결과가 이미 있으면 건너뜀 → 재시도·중복 실행에 안전
- 실패는 숨기지 않음: 일시 오류는 예외로 종료(→ 자동 재시도), 데이터 없음은 경고 로그 후 정상 종료
- 구조화 로그: JSON 한 줄 + severity → Cloud Logging 필터·알림
"""
from __future__ import annotations

import datetime as dt
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.he import MODEL_FAST, PROJECT, genai_client, query, table  # noqa: E402

REGIONS = ["수도권", "충청", "호남", "영남", "강원"]
TASK = int(os.getenv("CLOUD_RUN_TASK_INDEX", "0"))        # 0부터. Cloud Run이 태스크마다 넣어 줌
COUNT = int(os.getenv("CLOUD_RUN_TASK_COUNT", "1"))
ATTEMPT = int(os.getenv("CLOUD_RUN_TASK_ATTEMPT", "0"))
BUCKET = os.getenv("OUT_BUCKET", "")                        # 비우면 로컬 out/ 폴더
RUN_DATE = os.getenv("RUN_DATE") or (dt.date.today() - dt.timedelta(days=1)).isoformat()


def log(severity: str, msg: str, **kw):
    print(json.dumps({"severity": severity, "message": msg, "task": TASK, "attempt": ATTEMPT, "run_date": RUN_DATE, **kw},
                     ensure_ascii=False, default=str), flush=True)


def out_path(region: str) -> str:
    return f"daily/{RUN_DATE}/{region}.json"


def exists(path: str) -> bool:
    if BUCKET:
        from google.cloud import storage
        return storage.Client().bucket(BUCKET).blob(path).exists()
    return (Path("out") / path).exists()


def save(path: str, data: dict):
    body = json.dumps(data, ensure_ascii=False, indent=1, default=str)
    if BUCKET:
        from google.cloud import storage
        storage.Client().bucket(BUCKET).blob(path).upload_from_string(body, content_type="application/json")
    else:
        p = Path("out") / path; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(body, encoding="utf-8")


def collect(region: str) -> dict:
    since = (dt.date.fromisoformat(RUN_DATE) - dt.timedelta(days=6)).isoformat()
    rows = query(f"""
      SELECT s.site_name, s.model, COUNT(*) AS tickets, COUNTIF(t.recur_30d='Y') AS recur,
             COUNTIF(t.fault_code='E90') AS trapped, ROUND(AVG(t.arrival_min),1) AS avg_arrival,
             COUNTIF(t.status != '완료') AS open_cnt
      FROM {table('as_tickets')} t JOIN {table('sites')} s USING (site_id)
      WHERE s.region = @r AND DATE(t.received_at) BETWEEN CAST(@since AS DATE) AND CAST(@d AS DATE)
      GROUP BY 1,2 ORDER BY recur DESC, tickets DESC""", {"r": region, "since": since, "d": RUN_DATE})
    return {"region": region, "period": [since, RUN_DATE], "sites": rows,
            "total": sum(r["tickets"] for r in rows), "trapped": sum(r["trapped"] for r in rows)}


def summarize(facts: dict) -> str:
    if os.getenv("SKIP_LLM") == "1":
        return f"[요약 생략] {facts['region']} 7일 접수 {facts['total']}건, 갇힘 {facts['trapped']}건"
    r = genai_client().models.generate_content(
        model=MODEL_FAST,
        contents=("아래 7일간 권역 AS 집계로 서비스팀장용 아침 브리핑 3줄을 쓰세요. 숫자는 집계에 있는 값만 쓰고, "
                  "갇힘이 있으면 첫 줄에 적으세요.\n" + json.dumps(facts, ensure_ascii=False, default=str)))
    return r.text


def main():
    mine = [r for i, r in enumerate(REGIONS) if i % COUNT == TASK]   # 태스크 수가 5보다 적어도 모든 권역을 나눠 맡음
    log("INFO", "start", regions=mine)
    for region in mine:
        path = out_path(region)
        if exists(path):
            log("INFO", "skip: already done", region=region, path=path); continue
        facts = collect(region)
        if facts["total"] == 0:
            log("WARNING", "no data", region=region); continue
        save(path, {**facts, "summary": summarize(facts), "generated_at": dt.datetime.now().isoformat()})
        log("INFO", "saved", region=region, path=path, total=facts["total"], trapped=facts["trapped"])
    log("INFO", "done")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:                       # 예외 종료 → Cloud Run이 이 태스크만 재시도
        log("ERROR", f"failed: {e}", error_type=type(e).__name__)
        sys.exit(1)
