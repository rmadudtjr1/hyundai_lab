"""현대엘리베이터 과정 2 실습용 가상 데이터 생성기 (seed 고정, 실행할 때마다 같은 결과).

python 00_setup/make_data.py            # 00_setup/data/*.csv, rag_docs.jsonl 생성
python 00_setup/make_data.py --big      # cost_detail 20만 행까지 생성 (04장용, 약 15MB)

모든 회사·현장·인물·금액은 가상입니다.
"""
import csv, json, random, sys, datetime as dt
from pathlib import Path

OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)
R = random.Random(20261025)

REGIONS = ["수도권", "충청", "호남", "영남", "강원"]
DIVS = ["신규설치", "유지관리", "리모델링", "해외"]
MODELS = {"HM-300": (2015, 2023), "HM-500": (2012, 2022), "HM-700": (2005, 2011), "HM-900": (2019, 2025)}
CODES = {"E10": "도어 스위치 이상", "E21": "브레이크 라이닝 마모", "E35": "인버터 과열",
         "E42": "착상 오차", "E57": "원격감시 통신 이상", "E90": "승객 갇힘"}
PFX = {"수도권": ["강변", "판교", "마곡", "송도", "광교", "일산"], "충청": ["세종", "청주", "천안", "대전 둔산"],
       "호남": ["광주 상무", "전주 에코", "순천", "여수 웅천"], "영남": ["부산 마린시티", "부산 해운대", "대구 수성", "울산 삼산", "창원 중앙"],
       "강원": ["춘천", "원주 혁신", "강릉 교동"]}
SFX = ["타워", "센트럴", "파크", "메디컬센터", "오피스", "레지던스", "A동", "B동"]


def write(name, header, rows):
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    print(f"{name}: {len(rows):,}행")


# ---------- sites ----------
sites, seen = [], set()
for reg, pfx in PFX.items():
    for p in pfx:
        for _ in range(2):
            name = f"{p} {R.choice(SFX)}"
            if name in seen: continue
            seen.add(name)
            m = R.choices(list(MODELS), [4, 4, 2, 3])[0]
            y = R.randint(*MODELS[m])
            sites.append([f"S{len(sites)+1:03d}", name, reg, m, y, R.choice([4, 6, 8, 12, 16]), R.choice(["아파트", "오피스", "병원", "상가"])])
# 핵심 재발 현장 3곳 고정
for sid, name, reg, y in [("S901", "해솔타워", "수도권", 2008), ("S902", "부산 마린시티 A동", "영남", 2009), ("S903", "서현 메디컬센터", "충청", 2008)]:
    sites.append([sid, name, reg, "HM-700", y, 6, "오피스" if sid != "S903" else "병원"])
write("sites.csv", ["site_id", "site_name", "region", "model", "installed_year", "units", "building_type"], sites)
site_by = {s[0]: s for s in sites}

# ---------- as_tickets (2026Q3) ----------
ARR = {"수도권": 27, "충청": 37, "호남": 41, "영남": 35, "강원": 90}
tickets = []
def ticket(sid, code, recur):
    s = site_by[sid]
    t = dt.datetime(2026, 7, 1, 7) + dt.timedelta(days=R.randint(0, 91), minutes=R.randint(0, 900))
    arr = max(10, int(R.gauss(ARR[s[2]], ARR[s[2]] * .25)))
    tickets.append([None, t.strftime("%Y-%m-%d %H:%M:%S"), sid, code, CODES[code], arr, R.choice(["완료", "완료", "완료", "부품 대기"]), recur])
for sid, n, rep, cs in [("S901", 26, 18, ["E21", "E42"]), ("S902", 20, 14, ["E10", "E21"]), ("S903", 14, 9, ["E35", "E21"])]:
    flags = ["Y"] * rep + ["N"] * (n - rep); R.shuffle(flags)
    for f in flags: ticket(sid, R.choice(cs), f)
normal = [s[0] for s in sites if not s[0].startswith("S9")]
while len(tickets) < 820:
    sid = R.choice(normal); m = site_by[sid][3]
    ticket(sid, R.choices(list(CODES)[:5], [5, 3, 2, 3, 3])[0], "Y" if R.random() < (.55 if m == "HM-700" else .08) else "N")
for reg, a in [("강원", 118), ("강원", 86), ("영남", 47), ("호남", 52), ("충청", 34), ("수도권", 21), ("수도권", 18)]:
    sid = R.choice([s[0] for s in sites if s[2] == reg and not s[0].startswith("S9")]); ticket(sid, "E90", "N"); tickets[-1][5] = a
tickets.sort(key=lambda r: r[1])
for i, r in enumerate(tickets, 1): r[0] = f"T{i:05d}"
write("as_tickets.csv", ["ticket_id", "received_at", "site_id", "fault_code", "symptom", "arrival_min", "status", "recur_30d"], tickets)

# ---------- orders (2025-01 ~ 2026-09) ----------
orders = []
d0 = dt.date(2025, 1, 1)
for i in range(900):
    d = d0 + dt.timedelta(days=R.randint(0, 637))
    div = R.choices(DIVS, [4, 2, 3, 1])[0]
    reg = "해외" if div == "해외" else R.choice(REGIONS)
    stage = R.choices(["WON", "LOST", "BIDDING", "NEGOTIATION"], [55, 20, 15, 10])[0]
    if reg == "영남" and d >= dt.date(2026, 7, 1) and R.random() < .35: stage = "LOST"
    amt = round(R.uniform(150, 1800), 1)
    comp = R.choices(["A사", "B사", "C사", ""], [3, 3, 5, 1])[0] if stage == "LOST" else ""
    orders.append([f"O{i+1:05d}", d.isoformat(), div, reg, f"고객{R.randint(1,120):03d}", amt, stage, comp])
orders.sort(key=lambda r: r[1])
write("orders.csv", ["order_id", "order_date", "division", "region", "customer_id", "amount_mkrw", "stage", "competitor"], orders)

# ---------- pl_monthly ----------
pl = []
for y, m in [(y, m) for y in (2025, 2026) for m in range(1, 13) if not (y == 2026 and m > 9)]:
    for div in DIVS:
        regs = ["해외"] if div == "해외" else REGIONS
        for reg in regs:
            base = {"신규설치": 900, "유지관리": 520, "리모델링": 610, "해외": 1400}[div] * (1.2 if reg == "수도권" else 1)
            rev = round(base * R.uniform(.85, 1.15), 1)
            cogs_rate = {"신규설치": .78, "유지관리": .62, "리모델링": .71, "해외": .83}[div] + (.04 if (div == "리모델링" and y == 2026 and m >= 7) else 0)
            cogs = round(rev * R.uniform(cogs_rate - .03, cogs_rate + .03), 1)
            sga = round(rev * R.uniform(.08, .12), 1)
            pl.append([f"{y}-{m:02d}-01", div, reg, rev, cogs, sga])
write("pl_monthly.csv", ["month", "division", "region", "revenue_mkrw", "cogs_mkrw", "sga_mkrw"], pl)

# ---------- cost_detail ----------
N = 200_000 if "--big" in sys.argv else 20_000
ITEMS = ["자재-권상기", "자재-도어", "자재-제어반", "자재-로프", "외주시공", "운송", "인건비", "장비임차"]
rows = []
for i in range(N):
    d = dt.date(2025, 1, 1) + dt.timedelta(days=R.randint(0, 637))
    div = R.choices(DIVS, [4, 2, 3, 1])[0]
    reg = "해외" if div == "해외" else R.choice(REGIONS)
    item = R.choice(ITEMS)
    amt = round(R.lognormvariate(1.2, .9), 2)
    if item == "자재-제어반" and d >= dt.date(2026, 7, 1): amt = round(amt * 1.35, 2)  # 3분기 반도체 단가 상승 (분석 포인트)
    rows.append([f"C{i+1:07d}", d.isoformat(), div, reg, item, f"V{R.randint(1,60):03d}", amt])
write("cost_detail.csv", ["cost_id", "cost_date", "division", "region", "cost_item", "vendor_id", "amount_mkrw"], rows)

# ---------- rag_docs ----------
docs = [
    {"doc_id": "D01", "title": "승강기 유지관리 표준 절차", "dept": "svc", "level": "INTERNAL",
     "text": "정기 점검은 월 1회. 30일 내 같은 현장 재접수는 재발로 보고 선임기사가 동행 점검한다. HM-700은 브레이크 드럼 편마모를 함께 점검한다."},
    {"doc_id": "D02", "title": "승객 갇힘 대응 지침", "dept": "all", "level": "PUBLIC",
     "text": "갇힘 신고 시 30분 이내 도착을 목표로 하며 구출은 2인 1조로 한다. 사고 등록은 24시간 이내에 한다."},
    {"doc_id": "D03", "title": "2026 영업 수주 전략 (대외비)", "dept": "sales", "level": "CONFIDENTIAL",
     "text": "4분기 리모델링 수주 목표는 전년 대비 18% 증가. 영남 권역은 HM-700 노후 현장 중심으로 제안한다."},
    {"doc_id": "D04", "title": "리모델링 할인 승인 기준", "dept": "sales", "level": "CONFIDENTIAL",
     "text": "4분기 리모델링 할인 한도는 영업팀장 5%, 본부장 8%, 그 이상은 계약심의위원회 승인."},
    {"doc_id": "D05", "title": "2026년 3분기 사업부 손익 요약", "dept": "fin", "level": "RESTRICTED",
     "text": "리모델링 사업부 3분기 원가율이 4%p 상승. 제어반 자재 단가 상승이 주요 원인으로 추정."},
    {"doc_id": "D06", "title": "2027 인력 운영 계획 (인사)", "dept": "hr", "level": "RESTRICTED",
     "text": "서비스 기사 신규 채용 40명, 강원 권역 협력사 출동 계약 확대 검토."},
    {"doc_id": "D07", "title": "출장 및 출동 경비 규정", "dept": "all", "level": "INTERNAL",
     "text": "야간 출동 3만원, 휴일 출동 5만원, 겹치면 휴일 수당만 지급."},
    {"doc_id": "D08", "title": "서비스 품질 주간 보고 (재발 현장)", "dept": "svc", "level": "CONFIDENTIAL",
     "text": "해솔타워 재발 18건, 부산 마린시티 A동 14건. 두 현장 모두 HM-700으로 리모델링 제안 대상."},
]
with open(OUT / "rag_docs.jsonl", "w", encoding="utf-8") as f:
    for d in docs: f.write(json.dumps(d, ensure_ascii=False) + "\n")
print(f"rag_docs.jsonl: {len(docs)}건")

# 사용자 디렉터리 (05장, 실제로는 IdP 그룹)
users = [
    {"email": "svc01@example.com", "name": "서비스 기사", "depts": ["svc"], "clearance": 1},
    {"email": "svclead@example.com", "name": "서비스 팀장", "depts": ["svc"], "clearance": 2},
    {"email": "sales01@example.com", "name": "영업 담당", "depts": ["sales"], "clearance": 2},
    {"email": "cfo@example.com", "name": "재무 임원", "depts": ["fin", "sales", "svc"], "clearance": 3},
]
(OUT / "users.json").write_text(json.dumps(users, ensure_ascii=False, indent=1), encoding="utf-8")
print("users.json: 4명")
