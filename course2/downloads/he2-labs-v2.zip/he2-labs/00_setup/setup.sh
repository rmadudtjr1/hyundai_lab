#!/usr/bin/env bash
# 실습 프로젝트 준비 (팀별 1회). 사용: PROJECT_ID=he-ax-lab-team1 REGION=asia-northeast3 bash 00_setup/setup.sh
set -euo pipefail
: "${PROJECT_ID:?PROJECT_ID 필요}"
REGION="${REGION:-asia-northeast3}"; DATASET="${BQ_DATASET:-he_ax}"
cd "$(dirname "$0")"
gcloud config set project "$PROJECT_ID"

echo "[1/5] API 사용 설정"
gcloud services enable aiplatform.googleapis.com bigquery.googleapis.com run.googleapis.com \
  cloudbuild.googleapis.com artifactregistry.googleapis.com cloudscheduler.googleapis.com \
  workflows.googleapis.com eventarc.googleapis.com secretmanager.googleapis.com \
  discoveryengine.googleapis.com modelarmor.googleapis.com geminidataanalytics.googleapis.com \
  cloudresourcemanager.googleapis.com monitoring.googleapis.com logging.googleapis.com

echo "[2/5] 가상 데이터 생성 (cost_detail 20만 행)"
python make_data.py --big

echo "[3/5] BigQuery 적재 (열 설명 포함 = 시맨틱 레이어 1단계)"
bq --location="$REGION" mk -f --dataset --description "현대엘리베이터 AX 실습 (가상 데이터)" "$PROJECT_ID:$DATASET"
for t in sites as_tickets orders pl_monthly cost_detail; do
  bq --location="$REGION" load --replace --source_format=CSV --skip_leading_rows=1 \
     "$PROJECT_ID:$DATASET.$t" "data/$t.csv" "schema/$t.bq.json"
  bq update --description "$(python -c "import json;print(json.load(open('schema/$t.json'))['description'])")" "$PROJECT_ID:$DATASET.$t"
done

echo "[4/5] 버킷·서비스 계정"
gcloud storage buckets create "gs://${PROJECT_ID}-he-lab" --location="$REGION" 2>/dev/null || true
gcloud iam service-accounts create he-lab-runner --display-name="실습 실행 계정" 2>/dev/null || true
SA="he-lab-runner@${PROJECT_ID}.iam.gserviceaccount.com"
for r in roles/bigquery.dataViewer roles/bigquery.jobUser roles/aiplatform.user roles/storage.objectAdmin roles/logging.logWriter roles/modelarmor.user; do
  gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:$SA" --role="$r" --condition=None >/dev/null
done

echo "[5/5] 예산 알림은 결제 관리자가 콘솔에서 50/90/100%로 설정하세요."
echo "완료: ${PROJECT_ID}.${DATASET}"
