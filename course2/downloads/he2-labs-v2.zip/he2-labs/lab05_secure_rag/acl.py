"""권한 모델: RBAC(부서 토큰) + ABAC(보안등급 숫자). 검색 필터와 원문 재확인이 같은 규칙을 씁니다."""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "00_setup" / "data"
LEVEL = {"PUBLIC": 0, "INTERNAL": 1, "CONFIDENTIAL": 2, "RESTRICTED": 3}


@dataclass(frozen=True)
class User:
    email: str
    depts: tuple[str, ...]
    clearance: int
    name: str = ""


DIRECTORY = {u["email"]: User(u["email"], tuple(u["depts"]), u["clearance"], u["name"])
             for u in json.loads((DATA / "users.json").read_text(encoding="utf-8"))}


def resolve_user(verified_email: str) -> User:
    """ID 토큰 검증을 통과한 이메일만 받습니다. 디렉터리에 없으면 최소 권한(공개 문서만)."""
    return DIRECTORY.get(verified_email, User(verified_email, (), 0, "미등록"))


def verify_id_token(token: str, audience: str) -> str:
    """웹·API 서버에서 쓰는 신원 확인. 클라이언트가 보낸 부서·등급 값은 절대 쓰지 않습니다."""
    import google.auth.transport.requests
    from google.oauth2 import id_token
    info = id_token.verify_oauth2_token(token, google.auth.transport.requests.Request(), audience)
    if not info.get("email_verified"):
        raise PermissionError("이메일이 검증되지 않은 토큰")
    return info["email"]


def doc_restricts(doc: dict) -> tuple[list[str], int]:
    """문서 → (부서 토큰 목록, 등급 숫자). 전사 공개 문서는 'all'."""
    return [doc["dept"]], LEVEL[doc["level"]]


def user_filter(u: User) -> tuple[list[str], int]:
    """사용자 → 검색 필터. 부서 토큰은 OR(소속 부서 + all), 등급은 '이하'."""
    return list(u.depts) + ["all"], u.clearance


def allowed(u: User, doc_tokens: list[str], doc_level: int) -> bool:
    toks, clr = user_filter(u)
    return bool(set(toks) & set(doc_tokens)) and doc_level <= clr
