"""클라우드 없이 권한 규칙 확인: 사용자별로 보이는 문서, 같은 질문의 다른 근거, 태그 오류 방어.
python local_demo.py
(검색은 단순 키워드 점수로 대신합니다. 실제 실습은 index_docs.py + rag_query.py)
"""
import json
from acl import DATA, DIRECTORY, allowed, doc_restricts, resolve_user, user_filter

DOCS = [json.loads(l) for l in (DATA / "rag_docs.jsonl").read_text(encoding="utf-8").splitlines()]


def keyword_search(q, docs, k=3):
    score = lambda d: sum(w in (d["title"] + d["text"]) for w in q.split())
    return [d for d in sorted(docs, key=score, reverse=True) if score(d) > 0][:k]


def search(q, user, index_tags=None):
    """③ 필터 검색 → ④ 원문 재확인. index_tags로 '인덱스에 잘못 붙은 태그'를 흉내 냅니다."""
    toks, clr = user_filter(user)
    tagged = []
    for d in DOCS:
        dt, dl = (index_tags or {}).get(d["doc_id"], doc_restricts(d))
        if set(toks) & set(dt) and dl <= clr:            # 검색 엔진 필터 (인덱스의 태그 기준)
            tagged.append(d)
    hits = keyword_search(q, tagged)
    return [d for d in hits if allowed(user, *doc_restricts(d))]   # 원본 문서 저장소의 권한으로 이중 확인


print("사용자별로 보이는 문서")
for email, u in DIRECTORY.items():
    vis = [d["doc_id"] for d in DOCS if allowed(u, *doc_restricts(d))]
    print(f"  {u.name:<6} {email:<20} 부서{list(u.depts)} 등급{u.clearance} → {vis}")
print("  미등록 사용자 →", [d["doc_id"] for d in DOCS if allowed(resolve_user("x@example.com"), *doc_restricts(d))])

q = "4분기 리모델링 할인 한도"
print(f"\n질문: {q}")
for email in ["sales01@example.com", "svc01@example.com", "cfo@example.com"]:
    u = resolve_user(email)
    print(f"  {u.name:<6} → {[d['doc_id'] + ' ' + d['title'] for d in search(q, u)] or '권한 안에서 찾은 문서 없음'}")

assert "D04" in [d["doc_id"] for d in search(q, resolve_user("sales01@example.com"))]
assert not search(q, resolve_user("svc01@example.com"))
bad = {"D05": (["all"], 0)}                          # 재무 RESTRICTED 문서에 실수로 '전사 공개' 태그
hits = search("리모델링 원가율 손익", resolve_user("svc01@example.com"), bad)
assert "D05" not in [d["doc_id"] for d in hits]
print("\n태그 오류(D05를 공개로 잘못 색인)도 원문 재확인에서 차단 OK")
