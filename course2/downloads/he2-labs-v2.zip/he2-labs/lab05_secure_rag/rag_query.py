"""권한 분리형 RAG 질의: ① 신원 → ② 입력 검사 → ③ 필터 검색 → ④ 원문 재확인 → ⑤ 생성 → ⑥ 출력 검사.

VS_ENDPOINT=... python rag_query.py sales01@example.com "4분기 리모델링 할인 한도는?"
CLI 실습에서는 이메일을 인자로 받지만, 서비스에서는 acl.verify_id_token()으로 얻은 이메일만 씁니다.
"""
import json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import MODEL_FAST, PROJECT, genai_client  # noqa: E402
from acl import DATA, allowed, doc_restricts, resolve_user, user_filter  # noqa: E402
import guard  # noqa: E402

DOCS = {d["doc_id"]: d for d in (json.loads(l) for l in (DATA / "rag_docs.jsonl").read_text(encoding="utf-8").splitlines())}
USE_GUARD = os.getenv("USE_MODEL_ARMOR", "1") == "1"


def search(query: str, user, k: int = 4) -> list[str]:
    from google.cloud import aiplatform
    from google.cloud.aiplatform.matching_engine.matching_engine_index_endpoint import Namespace, NumericNamespace
    from index_docs import VS_REGION, embed
    aiplatform.init(project=PROJECT, location=VS_REGION)
    toks, clearance = user_filter(user)
    ep = aiplatform.MatchingEngineIndexEndpoint(index_endpoint_name=os.environ["VS_ENDPOINT"])
    res = ep.find_neighbors(deployed_index_id=os.getenv("VS_DEPLOYED_ID", "he_secure_rag"),
                            queries=[embed([query], "RETRIEVAL_QUERY")[0]], num_neighbors=k,
                            filter=[Namespace("dept", toks, [])],                    # 부서 토큰 OR
                            numeric_filter=[NumericNamespace(name="level", value_int=clearance, op="LESS_EQUAL")])
    return [n.id for n in res[0]]


def ask(email: str, question: str) -> str:
    user = resolve_user(email)                                                      # ① 서버가 정한 권한
    if USE_GUARD and guard.check_prompt(question):                                  # ②
        return "보안 정책에 따라 처리할 수 없는 요청입니다."
    ids = search(question, user)                                                    # ③
    docs = [DOCS[i] for i in ids if i in DOCS and allowed(user, *doc_restricts(DOCS[i]))]   # ④
    if not docs:
        return "권한 범위 안에서 관련 문서를 찾지 못했습니다."
    ctx = "\n\n".join(f"[{d['doc_id']}] {d['title']}\n{d['text']}" for d in docs)
    ans = genai_client().models.generate_content(                                    # ⑤
        model=MODEL_FAST,
        contents=f"아래 문서만 근거로 답하고 문장 끝에 [문서ID]를 붙이세요. 문서에 없으면 모른다고 답하세요.\n\n{ctx}\n\n질문: {question}").text
    if USE_GUARD and guard.check_response(question, ans):                           # ⑥
        return "응답에 민감 정보가 포함되어 표시하지 않습니다."
    return ans


if __name__ == "__main__":
    print(ask(sys.argv[1], " ".join(sys.argv[2:])))
