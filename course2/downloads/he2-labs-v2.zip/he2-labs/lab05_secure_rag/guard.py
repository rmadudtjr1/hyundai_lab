"""Model Armor로 입력·출력 검사 (탈옥·프롬프트 인젝션·민감정보·유해 콘텐츠).
템플릿은 콘솔 또는 gcloud model-armor templates create 로 미리 만듭니다 (MA_TEMPLATE).
필요 권한: roles/modelarmor.user
"""
import os
import sys
from functools import lru_cache
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import PROJECT  # noqa: E402

MA_LOC = os.getenv("MA_LOCATION", "asia-northeast3")
TEMPLATE = f"projects/{PROJECT}/locations/{MA_LOC}/templates/{os.getenv('MA_TEMPLATE', 'he-rag-guard')}"


@lru_cache
def _client():
    from google.api_core.client_options import ClientOptions
    from google.cloud import modelarmor_v1
    return modelarmor_v1.ModelArmorClient(transport="rest",
                                          client_options=ClientOptions(api_endpoint=f"modelarmor.{MA_LOC}.rep.googleapis.com"))


def _blocked(result) -> bool:
    from google.cloud import modelarmor_v1
    return result.sanitization_result.filter_match_state == modelarmor_v1.FilterMatchState.MATCH_FOUND


def check_prompt(text: str) -> bool:
    """True면 차단."""
    from google.cloud import modelarmor_v1
    r = _client().sanitize_user_prompt(request=modelarmor_v1.SanitizeUserPromptRequest(
        name=TEMPLATE, user_prompt_data=modelarmor_v1.DataItem(text=text)))
    return _blocked(r)


def check_response(prompt: str, answer: str) -> bool:
    from google.cloud import modelarmor_v1
    r = _client().sanitize_model_response(request=modelarmor_v1.SanitizeModelResponseRequest(
        name=TEMPLATE, model_response_data=modelarmor_v1.DataItem(text=answer), user_prompt=prompt))
    return _blocked(r)
