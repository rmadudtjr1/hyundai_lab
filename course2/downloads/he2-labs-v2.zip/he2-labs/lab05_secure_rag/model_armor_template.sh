#!/usr/bin/env bash
# (강사, 1회) Model Armor 템플릿 생성: 프롬프트 인젝션·탈옥, 민감정보(SDP 기본), 유해 콘텐츠 중간 이상 차단
# gcloud model-armor 플래그 이름은 gcloud 버전에 따라 다를 수 있습니다. 실패하면 콘솔(보안 → Model Armor → 템플릿 만들기)에서 같은 설정으로 만드세요.
set -euo pipefail
: "${PROJECT_ID:?}"; LOC="${MA_LOCATION:-asia-northeast3}"
gcloud model-armor templates create he-rag-guard --project="$PROJECT_ID" --location="$LOC" \
  --pi-and-jailbreak-filter-settings-enforcement=enabled \
  --pi-and-jailbreak-filter-settings-confidence-level=medium-and-above \
  --basic-config-filter-enforcement=enabled \
  --rai-settings-filters='[{"filterType":"HARASSMENT","confidenceLevel":"MEDIUM_AND_ABOVE"},{"filterType":"DANGEROUS","confidenceLevel":"MEDIUM_AND_ABOVE"}]'
