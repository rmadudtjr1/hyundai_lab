"""Vector Search 인덱스 만들기·문서 적재 (restricts = 부서 토큰, numeric_restricts = 보안등급).

python index_docs.py create      # (강사, 1회) 스트리밍 인덱스 + 엔드포인트 + 배포. 수십 분 걸립니다.
VS_INDEX_ID=... python index_docs.py upsert
권한이 바뀌면 restricts만 다시 넣습니다: python index_docs.py retag D05
"""
import json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import PROJECT, genai_client  # noqa: E402
from acl import DATA, doc_restricts  # noqa: E402

VS_REGION = os.getenv("VS_REGION", "asia-northeast3")
EMBED_MODEL = os.getenv("EMBED_MODEL", "gemini-embedding-001")   # 당일 제공 모델 ID 확인
DIM = 768
DOCS = [json.loads(l) for l in (DATA / "rag_docs.jsonl").read_text(encoding="utf-8").splitlines()]


def embed(texts, task):
    from google.genai import types
    r = genai_client().models.embed_content(model=EMBED_MODEL, contents=texts,
                                            config=types.EmbedContentConfig(task_type=task, output_dimensionality=DIM))
    return [e.values for e in r.embeddings]


def create():
    from google.cloud import aiplatform
    aiplatform.init(project=PROJECT, location=VS_REGION)
    idx = aiplatform.MatchingEngineIndex.create_tree_ah_index(
        display_name="he-secure-rag", dimensions=DIM, approximate_neighbors_count=10,
        distance_measure_type="DOT_PRODUCT_DISTANCE", feature_norm_type="UNIT_L2_NORM",
        index_update_method="STREAM_UPDATE")
    ep = aiplatform.MatchingEngineIndexEndpoint.create(display_name="he-secure-rag-ep", public_endpoint_enabled=True)
    ep.deploy_index(index=idx, deployed_index_id="he_secure_rag", min_replica_count=1, max_replica_count=1)
    print(f"VS_INDEX_ID={idx.resource_name}\nVS_ENDPOINT={ep.resource_name}\nVS_DEPLOYED_ID=he_secure_rag")


def datapoint(doc, vec=None):
    from google.cloud.aiplatform_v1.types import IndexDatapoint
    toks, lvl = doc_restricts(doc)
    return IndexDatapoint(
        datapoint_id=doc["doc_id"], feature_vector=vec or [],
        restricts=[IndexDatapoint.Restriction(namespace="dept", allow_list=toks)],
        numeric_restricts=[IndexDatapoint.NumericRestriction(namespace="level", value_int=lvl)])  # 적재 시 op 없음


def upsert(ids=None):
    from google.cloud import aiplatform
    aiplatform.init(project=PROJECT, location=VS_REGION)
    idx = aiplatform.MatchingEngineIndex(index_name=os.environ["VS_INDEX_ID"])
    docs = [d for d in DOCS if not ids or d["doc_id"] in ids]
    vecs = embed([f"{d['title']}\n{d['text']}" for d in docs], "RETRIEVAL_DOCUMENT")
    idx.upsert_datapoints(datapoints=[datapoint(d, v) for d, v in zip(docs, vecs)])
    print(f"적재 {len(docs)}건")


def retag(ids):
    """문서 권한 변경: 벡터는 그대로 두고 restricts만 갱신."""
    from google.cloud import aiplatform
    aiplatform.init(project=PROJECT, location=VS_REGION)
    idx = aiplatform.MatchingEngineIndex(index_name=os.environ["VS_INDEX_ID"])
    idx.upsert_datapoints(datapoints=[datapoint(d) for d in DOCS if d["doc_id"] in ids], update_mask=["all_restricts"])
    print("restricts 갱신:", ids)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "upsert"
    {"create": create, "upsert": lambda: upsert(sys.argv[2:]), "retag": lambda: retag(sys.argv[2:])}[cmd]()
