#!/usr/bin/env bash
# GCP·모델 호출 없이 돌아가는 테스트 전체 (LAB_MODE=local)
set -euo pipefail
cd "$(dirname "$0")"
export LAB_MODE=local SKIP_LLM=1
[ -f 00_setup/data/as_tickets.csv ] || python 00_setup/make_data.py
echo "== lab01";  (cd lab01_agent && python test_local.py)
echo "== lab02";  (cd lab02_multimodal && python test_crosscheck.py)
echo "== lab03";  (cd lab03_semantic && python test_guard.py)
echo "== lab04";  (cd lab04_bigdata && TOKEN_BUDGET=8000 python test_local.py && rm -f chart_test.html)
echo "== lab05";  (cd lab05_secure_rag && python local_demo.py)
echo "== lab06";  (cd lab06_mcp && (PORT=8765 python server.py >/tmp/he_mcp.log 2>&1 &) && sleep 4 && python client_test.py http://localhost:8765/mcp; kill $(lsof -t -i:8765) 2>/dev/null || pkill -f "python server.py" || true)
echo "== lab07";  (cd lab07_automation && RUN_DATE=2026-09-30 python main.py >/dev/null && echo "as-daily OK" && rm -rf out)
echo "모든 로컬 테스트 통과"
