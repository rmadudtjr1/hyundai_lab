"""모든 실습이 같이 쓰는 설정·데이터 접근·모델 클라이언트.

LAB_MODE=local  : 00_setup/data 의 CSV를 DuckDB로 읽습니다 (GCP 없이 SQL 실행).
LAB_MODE=bq     : BigQuery 데이터셋을 씁니다 (기본값).
SQL은 항상 BigQuery 문법으로 씁니다. local 모드에서는 sqlglot이 DuckDB 문법으로 바꿔 실행합니다.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "00_setup" / "data"


def _load_env():
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()
PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT", "")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "global")          # 모델 호출 위치
REGION = os.getenv("REGION", "asia-northeast3")                    # BigQuery·Cloud Run 리전
DATASET = os.getenv("BQ_DATASET", "he_ax")
MODEL_FAST = os.getenv("MODEL_FAST", "gemini-3.8-flash")
MODEL_PRO = os.getenv("MODEL_PRO", "gemini-4-argon")
MODE = os.getenv("LAB_MODE", "bq")
TABLES = ["sites", "as_tickets", "orders", "pl_monthly", "cost_detail"]


def table(name: str) -> str:
    """BigQuery 전체 이름. local 모드에서도 같은 SQL을 쓰도록 항상 이 함수로 테이블을 적습니다."""
    return f"`{PROJECT or 'local'}.{DATASET}.{name}`"


@lru_cache
def genai_client():
    from google import genai
    return genai.Client(vertexai=True, project=PROJECT, location=LOCATION)


@lru_cache
def bq_client():
    from google.cloud import bigquery
    return bigquery.Client(project=PROJECT, location=REGION)


@lru_cache
def _duck():
    import duckdb
    con = duckdb.connect()
    for t in TABLES:
        f = DATA / f"{t}.csv"
        if f.exists():
            con.execute(f"CREATE VIEW {t} AS SELECT * FROM read_csv_auto('{f.as_posix()}', header=true)")
    return con


def to_duckdb(sql: str, params: dict | None = None) -> str:
    """BigQuery SQL → DuckDB SQL. 프로젝트·데이터셋 접두어를 지우고 @파라미터를 리터럴로 바꿉니다."""
    import sqlglot
    from sqlglot import exp
    tree = sqlglot.parse_one(sql, read="bigquery")
    for t in tree.find_all(exp.Table):
        t.set("catalog", None); t.set("db", None)
    params = params or {}

    def repl(node):
        if isinstance(node, exp.Parameter):
            name = node.name
            if name in params:
                v = params[name]
                return exp.Literal.number(v) if isinstance(v, (int, float)) else exp.Literal.string(str(v))
        return node
    tree = tree.transform(repl)
    return tree.sql(dialect="duckdb")


def query(sql: str, params: dict | None = None, max_bytes: int = 10**9) -> list[dict]:
    """SELECT를 실행해 dict 목록으로 돌려줍니다. 파라미터는 문자열을 이어 붙이지 않고 바인딩합니다."""
    params = params or {}
    if MODE == "local":
        cur = _duck().execute(to_duckdb(sql, params))
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]
    from google.cloud import bigquery
    qp = []
    for k, v in params.items():
        typ = "INT64" if isinstance(v, int) else "FLOAT64" if isinstance(v, float) else "STRING"
        qp.append(bigquery.ScalarQueryParameter(k, typ, v))
    cfg = bigquery.QueryJobConfig(query_parameters=qp, maximum_bytes_billed=max_bytes)
    return [dict(r) for r in bq_client().query(sql, job_config=cfg).result()]
