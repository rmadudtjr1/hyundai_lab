# he2-labs v2 · 현대엘리베이터 GCP 엔지니어 실무 과정 실습 코드

검증 기준일 2026-10-25 · Python 3.11+ · 모든 데이터는 가상입니다.

## 빠른 시작
```bash
python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
cp .env.example .env                      # 프로젝트 ID 등 수정
python 00_setup/make_data.py              # 가상 데이터 (local 모드용)
bash run_local_tests.sh                   # GCP 없이 도는 테스트 전체
gcloud auth login && gcloud auth application-default login
PROJECT_ID=he-ax-lab-team1 bash 00_setup/setup.sh   # BigQuery 적재 등 (팀별 1회)
```

| 폴더 | 모듈 | 로컬(LAB_MODE=local) | 클라우드 |
|---|---|---|---|
| lab01_agent | 01 Workflow Builder 범위와 ADK | 도구·콜백·그래프 시험 | adk web, Agent Runtime 배포, Gemini Enterprise 등록, adk eval |
| lab02_multimodal | 02 도면·PDF 멀티모달 | 판정 규칙 시험 | Gemini 추출 → 교차 검증 |
| lab03_semantic | 03 시맨틱 레이어 Text-to-SQL | 정적 검사·정답 SQL | nl2sql, evaluate, 관리형 데이터 에이전트 |
| lab04_bigdata | 04 대용량·토큰·차트 | 집계 단계 하향·차트 | count_tokens, 캐시, ChartPlan |
| lab05_secure_rag | 05 권한 분리 RAG | 권한 규칙 데모 | Vector Search restricts, Model Armor |
| lab06_mcp | 06 Cloud Run MCP 서버 | 서버·클라이언트 실제 통신 | Cloud Run, ADK·Gemini Enterprise·Antigravity 연결 |
| lab07_automation | 07 무중단 자동화 | 작업 실행·멱등성 | Cloud Run 작업, Scheduler, Workflows, 알림, VM MIG |

## 2026-10 기준 주의
- ADK 2.x: SequentialAgent·ParallelAgent·LoopAgent는 deprecated → `google.adk.Workflow` (lab01/proposal_flow)
- MCP SDK 2.x: `FastMCP` → `from mcp.server import MCPServer`, stateless·json 옵션은 `run()`에
- gemini-4-argon은 명시적 캐시 미지원 → 캐시 실습은 3.x Flash
- Agent Runtime은 global 위치 미지원 (서울 asia-northeast3 제공), CLI 이름은 여전히 `adk deploy agent_engine`
- GCP 실제 호출은 교육 전 강사 리허설로 확인하세요 (작성 환경에는 GCP 자격 증명이 없어 로컬 테스트까지만 검증).
