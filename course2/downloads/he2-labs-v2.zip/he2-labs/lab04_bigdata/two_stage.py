"""lab04 · 대용량 요약 2단계 파이프라인: 계산은 DB, 해석은 모델.

python two_stage.py "2026년 원가가 늘어난 항목과 원인 가설을 정리해 줘"
python two_stage.py --offline      # 모델 없이 집계 수준별 토큰 추정만 (local 모드)
"""
from __future__ import annotations
import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import MODEL_FAST, MODEL_PRO, genai_client, query, table  # noqa: E402

TOKEN_BUDGET = int(os.getenv("TOKEN_BUDGET", "30000"))   # 비용·품질 기준으로 정한 예산 (모델 한도가 아님)

LEVELS = [  # 세밀 → 굵게. 예산을 넘으면 다음 수준으로 내려갑니다.
    ("월×사업부×권역×항목", "FORMAT_DATE('%Y-%m', cost_date) AS ym, division, region, cost_item", "1, 2, 3, 4"),
    ("월×사업부×항목", "FORMAT_DATE('%Y-%m', cost_date) AS ym, division, cost_item", "1, 2, 3"),
    ("분기×사업부×항목", "CONCAT(CAST(EXTRACT(YEAR FROM cost_date) AS STRING), '-Q', CAST(EXTRACT(QUARTER FROM cost_date) AS STRING)) AS q, division, cost_item", "1, 2, 3"),
    ("분기×항목", "CONCAT(CAST(EXTRACT(YEAR FROM cost_date) AS STRING), '-Q', CAST(EXTRACT(QUARTER FROM cost_date) AS STRING)) AS q, cost_item", "1, 2"),
]


def aggregate(dims: str, groups: str) -> list[dict]:
    return query(f"""SELECT {dims}, ROUND(SUM(amount_mkrw), 1) AS amt, COUNT(*) AS n
                     FROM {table('cost_detail')} GROUP BY {groups} ORDER BY {groups}""", max_bytes=2 * 10**9)


def to_csv(rows: list[dict]) -> str:
    """JSON보다 CSV가 토큰이 적습니다 (키 반복 없음)."""
    keys = list(rows[0])
    return "\n".join([",".join(keys)] + [",".join(str(r[k]) for k in keys) for r in rows])


def count_tokens(text: str, offline: bool) -> int:
    if offline:
        return int(len(text) / 2.2)   # 대략치(한·영·숫자 혼합). 실제 값은 count_tokens로
    return genai_client().models.count_tokens(model=MODEL_FAST, contents=text).total_tokens


def pick_level(offline: bool = False):
    for name, dims, groups in LEVELS:
        rows = aggregate(dims, groups)
        payload = to_csv(rows)
        n = count_tokens(payload, offline)
        print(f"[{name}] {len(rows):,}행 → {n:,} 토큰 {'(예산 이내)' if n <= TOKEN_BUDGET else '(예산 초과 → 더 굵게)'}")
        if n <= TOKEN_BUDGET:
            return name, payload, n
    raise SystemExit("가장 굵은 집계도 예산을 넘습니다. 기간·범위를 좁히세요.")


def main(question: str, offline: bool):
    name, payload, n = pick_level(offline)
    if offline:
        return
    from google.genai import types
    resp = genai_client().models.generate_content(
        model=MODEL_PRO,
        contents=f"원가 집계표({name}, 단위 백만원):\n{payload}\n\n질문: {question}",
        config=types.GenerateContentConfig(
            system_instruction=("당신은 원가 분석가입니다. 집계표에 있는 숫자만 인용합니다. "
                                "원인은 데이터로 확인되지 않으면 '가설'로 표시하고, 확인에 필요한 추가 데이터를 제안합니다."),
            temperature=0.2))
    print("\n" + resp.text)
    u = resp.usage_metadata
    print(f"\n[사용 토큰] 입력 {u.prompt_token_count:,} · 출력 {u.candidates_token_count:,}")


if __name__ == "__main__":
    off = "--offline" in sys.argv
    q = " ".join(a for a in sys.argv[1:] if a != "--offline") or "2026년 원가가 늘어난 항목과 원인 가설을 정리해 줘"
    main(q, off)
