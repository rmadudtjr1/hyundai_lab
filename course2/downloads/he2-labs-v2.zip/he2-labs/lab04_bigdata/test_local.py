"""LLM 없이: 집계 단계 하향과 차트 렌더링 확인.  LAB_MODE=local python test_local.py"""
import os; os.environ.setdefault("LAB_MODE", "local"); os.environ.setdefault("TOKEN_BUDGET", "8000")
import pandas as pd
from two_stage import pick_level, aggregate, LEVELS
from viz import ChartPlan, render
name, payload, n = pick_level(offline=True); print("선택:", name, n)
df = pd.DataFrame(aggregate(*LEVELS[3][1:]))
q3 = df[df.cost_item == "자재-제어반"].set_index("q")["amt"]; print("자재-제어반 분기 원가:", q3.to_dict())
print("렌더:", render(ChartPlan(mark="line", x="q", y="amt", color="cost_item", title="분기별 원가 항목 추이"), df, "chart_test.html"))
try:
    render(ChartPlan(mark="bar", x="month", y="amt", title="x"), df)
except ValueError as e:
    print("없는 열 차단 OK:", e)
