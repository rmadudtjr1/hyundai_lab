"""lab04 · 동적 시각화: 모델은 '차트 계획'만, 데이터는 코드가 붙입니다 (값 환각 방지).

python viz.py "월별 사업부 원가 추이"     # 모델이 ChartPlan → altair가 chart.html (확대·툴팁)
"""
from __future__ import annotations
import sys
from pathlib import Path
from typing import Literal, Optional
import pandas as pd
from pydantic import BaseModel, Field
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import MODEL_FAST, genai_client  # noqa: E402


class ChartPlan(BaseModel):
    mark: Literal["line", "bar", "area", "point"]
    x: str = Field(description="x축 열 이름 (주어진 열 중 하나)")
    y: str = Field(description="y축 열 이름 (숫자 열)")
    color: Optional[str] = Field(default=None, description="계열 구분 열. 없으면 null")
    title: str


def plan_chart(question: str, df: pd.DataFrame) -> ChartPlan:
    from google.genai import types
    cols = ", ".join(f"{c}({df[c].dtype})" for c in df.columns)
    r = genai_client().models.generate_content(
        model=MODEL_FAST, contents=f"질문: {question}\n열: {cols}\n이 질문에 맞는 차트 계획을 고르세요.",
        config=types.GenerateContentConfig(response_mime_type="application/json",
                                           response_json_schema=ChartPlan.model_json_schema(), temperature=0))
    return ChartPlan.model_validate_json(r.text)


def render(plan: ChartPlan, df: pd.DataFrame, path: str = "chart.html") -> str:
    import altair as alt
    for col in [plan.x, plan.y] + ([plan.color] if plan.color else []):
        if col not in df.columns:
            raise ValueError(f"모델이 없는 열을 골랐습니다: {col}")   # 검증 실패 → 다시 계획하거나 기본 차트
    enc = {"x": alt.X(plan.x), "y": alt.Y(plan.y), "tooltip": list(df.columns)}
    if plan.color:
        enc["color"] = alt.Color(plan.color)
    chart = getattr(alt.Chart(df), f"mark_{plan.mark}")().encode(**enc).properties(title=plan.title, width=720, height=360).interactive()
    chart.save(path)
    return path


if __name__ == "__main__":
    from two_stage import aggregate, LEVELS
    df = pd.DataFrame(aggregate(*LEVELS[1][1:]))
    df = df.groupby(["ym", "division"], as_index=False)["amt"].sum()
    q = " ".join(sys.argv[1:]) or "월별 사업부 원가 추이"
    p = plan_chart(q, df); print(p)
    print("저장:", render(p, df))
