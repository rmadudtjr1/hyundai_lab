"""lab04 · 명시적 컨텍스트 캐시: 같은 집계표로 여러 질문을 할 때 집계표를 한 번만 올립니다.

python cache_context.py
주의: gemini-4-argon은 명시적 캐시(caches.create)를 지원하지 않습니다 → MODEL_CACHE(3.x Flash)로 실습.
최소 캐시 크기는 모델별로 다릅니다(3.8 Flash 4,096 토큰). 너무 작으면 생성이 거부됩니다.
"""
import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.he import genai_client  # noqa: E402
from two_stage import LEVELS, aggregate, to_csv  # noqa: E402
from google.genai import types

MODEL_CACHE = os.getenv("MODEL_CACHE", "gemini-3.8-flash")
QUESTIONS = ["2026년 3분기에 전년 같은 분기보다 가장 많이 늘어난 원가 항목은?",
             "리모델링 사업부의 분기별 자재-제어반 원가 추이를 표로 보여 줘",
             "운송비가 가장 큰 사업부와 그 비중은?"]


def main():
    client = genai_client()
    name, dims, groups = LEVELS[1]                       # 월×사업부×항목
    data = to_csv(aggregate(dims, groups))
    cache = client.caches.create(
        model=MODEL_CACHE,
        config=types.CreateCachedContentConfig(
            display_name="cost-detail-agg",
            system_instruction="당신은 원가 분석가입니다. 캐시된 집계표의 숫자로만 답합니다. 단위는 백만원.",
            contents=[types.Content(role="user", parts=[types.Part.from_text(text=f"원가 집계표({name}):\n{data}")])],
            ttl="1800s"))
    print("캐시:", cache.name, "토큰", cache.usage_metadata.total_token_count)
    try:
        for q in QUESTIONS:
            r = client.models.generate_content(model=MODEL_CACHE, contents=q,
                                               config=types.GenerateContentConfig(cached_content=cache.name, temperature=0))
            u = r.usage_metadata
            print(f"\nQ: {q}\n{r.text[:600]}\n[입력 {u.prompt_token_count:,} 중 캐시 {u.cached_content_token_count or 0:,}]")
    finally:
        client.caches.delete(name=cache.name)          # 보관 시간만큼 저장 비용이 붙으므로 끝나면 지웁니다
        print("\n캐시 삭제")


if __name__ == "__main__":
    main()
