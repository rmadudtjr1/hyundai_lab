#!/usr/bin/env bash
# 이 폴더의 CSV를 BigQuery에 적재 (열 설명 포함). 사용: PROJECT_ID=he-ax-lab-team1 bash load_bq.sh
set -euo pipefail
: "${PROJECT_ID:?}"; REGION="${REGION:-asia-northeast3}"; DATASET="${BQ_DATASET:-he_ax}"
cd "$(dirname "$0")"
bq --location="$REGION" mk -f --dataset "$PROJECT_ID:$DATASET"
for t in sites as_tickets orders pl_monthly cost_detail; do
  bq --location="$REGION" load --replace --source_format=CSV --skip_leading_rows=1 "$PROJECT_ID:$DATASET.$t" "$t.csv" "${t}_schema.json"
done
echo "완료: $PROJECT_ID.$DATASET"
