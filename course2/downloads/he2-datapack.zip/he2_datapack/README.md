# 과정 2 실습 데이터팩 (GCP 엔지니어 실무 과정)

모든 데이터는 교육용 가상 데이터입니다. 실제 고객·현장·인물·금액과 관계없습니다.
같은 데이터가 실습 저장소 he2-labs의 `00_setup/make_data.py`로도 생성됩니다(seed 고정, 결과 동일).

| 폴더·파일 | 내용 | 모듈 |
|---|---|---|
| 00_데이터_사전.xlsx | 테이블별 열 설명, 행 수, 샘플 | 전체 |
| 01_BigQuery_테이블/ | sites 41 · as_tickets 827 · orders 900 · pl_monthly 336 · cost_detail 200,000행 CSV + 스키마(JSON, 한국어 열 설명) + load_bq.sh | 01, 03, 04, 06, 07 |
| 02_도면_사양서/ | 승강로 평면도·단면도 PNG, 기술 사양서 PDF (피트 깊이 의도적 불일치) | 02 |
| 03_시맨틱레이어/ | 용어사전 glossary.yaml, 검증 쿼리 verified_queries.yaml, 평가 세트 eval_set.yaml | 03 |
| 04_권한RAG_문서/ | 부서·보안등급이 붙은 사내 문서 8건(jsonl), 사용자 4명, 보기용 xlsx | 05 |
| 05_자동화_입력샘플/ | 일자별 AS 접수 CSV 2개. GCS `inbox/`에 올려 이벤트 실행 시험 | 07 |

BigQuery 적재: `PROJECT_ID=he-ax-lab-team1 bash 01_BigQuery_테이블/load_bq.sh`
(he2-labs의 `00_setup/setup.sh`를 쓰면 API 설정·서비스 계정까지 한 번에 됩니다.)
